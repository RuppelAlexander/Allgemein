<?php
/**
 * ------------------------------------------------------------------------------
 *  ISC it & software consultants GmbH
 * ------------------------------------------------------------------------------
 * Author        : DontG
 * Create Date   : 20.06.2018
 * Change Date   : 05.01.2021
 * Main Program  : global search across teams
 * Description   : Global Suche (teams übergreifend)
 * ------------------------------------------------------------------------------
 * Change Log    :
 * Date       name   Description
 * ------------------------------------------------------------------------------
 * ------------------------------------------------------------------------------
 */
require_once('clients/base/api/GlobalSearchApi.php');

class ISCGlobalSearchApi extends GlobalSearchApi
{
	/**
	 * @var array[] Modul->felderliste die additional mit angezeigt werden
	 */
	private $Isc_infoRowFields = [
		'Accounts' => [],
		'Contacts' => []
	];

	/**
	 * registerApiRest
	 * @return array|array[]
	 */
	public function registerApiRest()
	{
		//in case we want to add additional endpoints
		return parent::registerApiRest();
	}

	/**
	 * GlobalSearch endpoint
	 * @param ServiceBase $api
	 * @param array       $args
	 * @return array
	 */
	public function globalSearch(ServiceBase $api, array $args)
	{
		global $current_user;

		$response = parent::globalSearch($api, $args);
		foreach ($response['records'] as $id => &$Rec) {
			$id = $Rec['id'];
			$module = $Rec['_module'];
			$bean = BeanFactory::getBean($module, $id);
			$ISC_TeamSec = 0;
			if (empty($bean->id)) {
				$bean = BeanFactory::getBean($module, $id, array('disable_row_level_security' => true));
				$ISC_TeamSec = 1;
			}
			$infoRow = $this->buildInfoRow($bean);


			$OUserid = $bean->assigned_user_id;
			$OUsername = $bean->assigned_user_name;
			$Rec['_InfoRow'] = $infoRow;
			if ($ISC_TeamSec == 1) {
				$Rec['_OtherTeam'] = 1;
				$Rec['_OwnerUserId'] = $OUserid;
				$Rec['_OwnerUserName'] = $OUsername;
			} else {
				$Rec['_OtherTeam'] = 0;
				$Rec['_OwnerUserId'] = $OUserid;
				$Rec['_OwnerUserName'] = $OUsername;
			}
		}

		return $response;
	}

	/**
	 * Zusatzinfo fuer anzeige
	 * @param SugarBean $bean
	 * @return array
	 */
	private function buildInfoRow(SugarBean $bean)
	{
		global $app_list_strings;
		$infoRow = [];
		if (!empty($bean->id)) {
			$Fieldlist = $this->Isc_infoRowFields[$bean->module_dir] ?? [];
			if (is_array($Fieldlist)) {
				foreach ($Fieldlist as $fieldname) {
					if (isset($bean->field_defs[$fieldname])) {
						$value = $bean->{$fieldname};
						switch ($bean->field_defs[$fieldname]['type']) {
							case 'enum':
								$value = $app_list_strings[$bean->field_defs[$fieldname]['options']][$value] ?? $value;
								break;
						}
						$label = trim(translate($bean->field_defs[$fieldname]['vname'], $bean->module_name));
						if (substr($label, -1) != ':') {
							$label .= ':';
						}
						if (empty($value)) {
							$value = '---';
						}
						$infoRow[] = array('label' => $label, 'value' => $value);
					}
				}
			}
		}
		return $infoRow;
	}
}

