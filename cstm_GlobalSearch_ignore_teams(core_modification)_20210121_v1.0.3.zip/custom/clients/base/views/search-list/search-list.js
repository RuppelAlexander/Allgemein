/**
 * ------------------------------------------------------------------------------
 *  ISC it & software consultants GmbH
 * ------------------------------------------------------------------------------
 * Author        : DontG
 * Create Date   : 20.06.2018
 * Change Date   : 28.12.2020
 * Main Program  : global search across teams
 * Description   : Global Suche (teams übergreifend)
 * ------------------------------------------------------------------------------
 * Change Log    :
 * Date       name   Description
 * ------------------------------------------------------------------------------
 * ------------------------------------------------------------------------------
 */
({
    extendsFrom:'BaseSearchListView',

    /**
     * @inheritdoc
     */
    initialize: function (options) {
        this._super('initialize', [options]);

    },
    /**
     * Parses models to generate primary fields and secondary fields based on
     * the metadata and data sent by the globalsearch API. This is used to
     * render them properly in the template.
     *
     * @param {Data.Bean[]} models The models to parse.
     */
    parseModels: function (models) {
        var gsUtils = app.utils.GlobalSearch;
        _.each(models, function (model) {
            var moduleMeta = this._fieldsMeta[model.module] || gsUtils.getFieldsMeta(model.module);
            this._fieldsMeta[model.module] = moduleMeta;
            model.iscTeamsettings = {OtherTeam: model.attributes._OtherTeam, OwnerId: model.attributes._OwnerUserId, OwnerName: model.attributes._OwnerUserName};
            model.iscInfoRow=model.attributes._InfoRow;
            model.primaryFields = gsUtils.highlightFields(model, moduleMeta.primaryFields);
            model.secondaryFields = gsUtils.highlightFields(model, moduleMeta.secondaryFields, true);
            model.viewAccess = app.acl.hasAccessToModel('view', model);

            this._rejectEmptyFields(model, model.secondaryFields);

            model.primaryFields = this._sortHighlights(model.primaryFields);
            model.secondaryFields = this._sortHighlights(model.secondaryFields);
            if (model.attributes._OtherTeam) {
                _.each(model.primaryFields, function (field) {
                    field.link = false;
                });
                _.each(model.secondaryFields, function (field) {
                    field.link = false;
                });
            }
            model.rowactions = moduleMeta.rowactions;
        }, this);
    },

})
