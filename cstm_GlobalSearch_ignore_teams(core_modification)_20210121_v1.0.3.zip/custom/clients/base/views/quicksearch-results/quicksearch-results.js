/**
 * ------------------------------------------------------------------------------
 *  ISC it & software consultants GmbH
 * ------------------------------------------------------------------------------
 * Author        : DontG
 * Create Date   : 20.06.2018
 * Change Date   : 28.12.2020
 * Main Program  : global search across teams
 * Description   : Global Suche (teams übergreifend)
 * ------------------------------------------------------------------------------
 * Change Log    :
 * Date       name   Description
 * ------------------------------------------------------------------------------
 * ------------------------------------------------------------------------------
 */
({
    extendsFrom:'BaseQuicksearchResultsView',
    /**
     * @inheritdoc
     */
    initialize: function (options) {
        this._super('initialize', [options]);
    },

    /**
     * Parses models when collection resets and renders the view.
     *
     * @override
     */
    bindDataChange: function () {
        // On a collection sync, format the search results and display
        this.collection.on('sync', function (collection) {
            if (this.disposed) {
                return;
            }
            
            var gsUtils = app.utils.GlobalSearch;

            gsUtils.formatRecords(collection, false);

            _.each(this.collection.models, function (model) {
                model.viewAccess = app.acl.hasAccessToModel('view', model);
                model.iscTeamsettings = {
                    OtherTeam: model.attributes._OtherTeam,
                    OwnerId: model.attributes._OwnerUserId,
                    OwnerName: model.attributes._OwnerUserName
                };
                model.iscInfoRow=model.attributes._InfoRow;
                // FIXME: SC-4254 Remove this.layout.v2
                if (this.layout.v2) {
                    var moduleMeta = this._fieldsMeta[model.module] || gsUtils.getFieldsMeta(model.module, {linkablePrimary: false});
                    this._fieldsMeta[model.module] = moduleMeta;
                    model.primaryFields = gsUtils.highlightFields(model, moduleMeta.primaryFields);
                    model.secondaryFields = gsUtils.highlightFields(model, {}, true);

                    model.primaryFields = _.values(model.primaryFields);
                    model.secondaryFields = _.values(model.secondaryFields).slice(0, 3);
                    if (model.attributes._OtherTeam) {
                        _.each(model.primaryFields, function (field) {
                            field.link = false;
                        });
                        _.each(model.secondaryFields, function (field) {
                            field.link = false;
                        });
                    }
                } else {
                    if (model.searchInfo.highlighted) {
                        // Get the highlighted fields. If one is the name, highlight the name. Also, highlight the first
                        // non-name field. If there are multiple non-name highlighted fields, we only use the first.
                        _.find(model.searchInfo.highlighted, function (val, key) {
                            if (key === 'name') {
                                model.name = new Handlebars.SafeString(val.text);
                            } else { // found in a related field
                                model.field_name = app.lang.get(val.label, val.module);
                                model.field_value = new Handlebars.SafeString(val.text);
                                return true;
                            }
                        });
                    }
                }
            }, this);

            // build the link for View all results
            this.searchLink = app.utils.GlobalSearch.buildSearchRoute(collection.query, {
                modules: this.collection.selectedModules,
                tags: _.pluck(this.selectedTags, 'name')
            });
            this.activeIndex = null;
            this.render();
            this.open();

            // If the tags view is shown, move this one down
            var shownTags = _.pluck(collection.tags, 'name');
            var selectedTags = _.pluck(this.selectedTags, 'name');
            shownTags = _.difference(shownTags, selectedTags);
            this.$('.typeahead').toggleClass('tagsShown', shownTags.length > 0);
            this.layout.trigger('quicksearch:tag:' + shownTags.length > 0 ? 'open' : 'close');
        }, this);
    },

})
