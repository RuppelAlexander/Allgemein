<?php
/**
 * ------------------------------------------------------------------------------
 *  ISC it & software consultants GmbH
 * ------------------------------------------------------------------------------
 * Author        : DontG
 * Create Date   : 12.01.2021
 * Change Date   : 12.01.2021
 * Main Program  : sugarcrm_roedl
 * Description   : sugarcrm_roedl
 * ------------------------------------------------------------------------------
 * Change Log    :
 * Date       name   Description
 * ------------------------------------------------------------------------------
 * ------------------------------------------------------------------------------
 */
$app_strings['LBL_GSEARCH_FREMDTEAM'] = "Fremd";
$app_strings['LBL_GSEARCH_TEAM'] = 'Team ';
