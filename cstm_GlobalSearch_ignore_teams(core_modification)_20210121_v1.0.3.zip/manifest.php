<?php 
/*
* Copyright (C) ISC GmbH. All rights reserved.
*/

$manifest = array(
    'acceptable_sugar_versions' => array('regex_matches' => array( "7\.6\.*","7\.7\.*","7\.8\.*","7\.9\.*","8\.*","9\.*","10\.*")),
    'acceptable_sugar_flavors' => array('ENT','ULT','CORP','PRO'),
    'readme' => '',
    'key' => 'cstm_globalsearch',
    'author' => 'Dont G.',
    'description' => 'Global Suche (teams übergreifend) Firmen und Kontakte',
    'icon' => '',
    'is_uninstallable' => 'true',
    'name' => 'Global Suche (teams übergreifend)',
    'published_date' => '2021-01-21 15:45:00',
    'type' => 'module',
    'version' => '1.0.3',
    'remove_tables' => 'prompt',
); 

$installdefs = array(
    'id' => 'cstm_globalsearch',
    'language' =>  array(
        array(
            'from' => '<basepath>/custom/Extension/application/Ext/Language/de_DE.iscGlobalsearch.php',
            'to_module' => 'application',
            'language' => 'de_DE',
        ),
        array(
            'from' => '<basepath>/custom/Extension/application/Ext/Language/en_us.iscGlobalsearch.php',
            'to_module' => 'application',
            'language' => 'en_us',
        ),
    ),
    'copy' =>array(
        array(
            'from' => '<basepath>/custom/clients/base/api/IscGlobalSearchApi.php',
            'to' => 'custom/clients/base/api/IscGlobalSearchApi.php',
        ),
        array(
            'from' => '<basepath>/custom/clients/base/views/quicksearch-results/quicksearch-results.hbs',
            'to' => 'custom/clients/base/views/quicksearch-results/quicksearch-results.hbs',
        ),
        array(
            'from' => '<basepath>/custom/clients/base/views/quicksearch-results/quicksearch-results.js',
            'to' => 'custom/clients/base/views/quicksearch-results/quicksearch-results.js',
        ),
        array(
            'from' => '<basepath>/custom/clients/base/views/quicksearch-results/row.hbs',
            'to' => 'custom/clients/base/views/quicksearch-results/row.hbs',
        ),
        array(
            'from' => '<basepath>/custom/clients/base/views/quicksearch-results/team.hbs',
            'to' => 'custom/clients/base/views/quicksearch-results/team.hbs',
        ),
        array(
            'from' => '<basepath>/custom/clients/base/views/search-list/otherrow.hbs',
            'to' => 'custom/clients/base/views/search-list/otherrow.hbs',
        ),
        array(
            'from' => '<basepath>/custom/clients/base/views/search-list/row.hbs',
            'to' => 'custom/clients/base/views/search-list/row.hbs',
        ),
        array(
            'from' => '<basepath>/custom/clients/base/views/search-list/search-list.hbs',
            'to' => 'custom/clients/base/views/search-list/search-list.hbs',
        ),
        array(
            'from' => '<basepath>/custom/clients/base/views/search-list/search-list.js',
            'to' => 'custom/clients/base/views/search-list/search-list.js',
        ),
        array(
            'from' => '<basepath>/custom/clients/base/views/search-list/search-list.php',
            'to' => 'custom/clients/base/views/search-list/search-list.php',
        ),
        array(
            'from' => '<basepath>/custom/clients/base/views/search-list/team.hbs',
            'to' => 'custom/clients/base/views/search-list/team.hbs',
        ),
        array(
            'from' => '<basepath>/custom/clients/base/views/search-list/teamrow.hbs',
            'to' => 'custom/clients/base/views/search-list/teamrow.hbs',
        ),
         array(
            'from' => '<basepath>/data/visibility/TeamSecurity/NormalizedTeamSecurity.php',
            'to' => 'data/visibility/TeamSecurity/NormalizedTeamSecurity.php',
        ),
         array(
            'from' => '<basepath>/data/visibility/ACLVisibility.php',
            'to' => 'data/visibility/ACLVisibility.php',
        ),
    ),
);

