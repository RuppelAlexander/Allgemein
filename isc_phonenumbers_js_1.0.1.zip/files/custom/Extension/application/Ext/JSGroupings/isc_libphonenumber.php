<?php
/**
 * ----------------------------------------------------------------------------
 * © ISC it & software consultants GmbH  (All rights reserved.)
 * DO NOT MODIFY THIS FILE !
 * ----------------------------------------------------------------------------
 * Author        : RuppelA
 * Create Date   : 27.08.2025
 * Change Date   : 27.08.2025
 * Main Program  : ISC LibPhoneNumber
 * Description   : isc_libphonenumber.php
 * ----------------------------------------------------------------------------
 * Change Log    :
 * Date        Name    Description
 * ----------------------------------------------------------------------------
 * ----------------------------------------------------------------------------
 */

   //custom/Extension/application/Ext/JSGroupings/isc_libphonenumber.php

foreach ($js_groupings as $k => $group) {
    foreach ($group as $file => $target) {
        if ($target === 'include/javascript/sugar_grp7.min.js') {
            $js_groupings[$k]['custom/include/isc_libphonenumber/phonenumbers/libphonenumber-max.js'] = $target;
            $js_groupings[$k]['custom/modules/Contacts/clients/base/views/isc-phone-guard/isc-phone-guard.js'] = $target;
            $js_groupings[$k]['custom/modules/Accounts/clients/base/views/isc-phone-guard/isc-phone-guard.js'] = $target;
            $js_groupings[$k]['custom/modules/Accounts/clients/base/fields/editablelistbutton/editablelistbutton.js'] = $target;
            $js_groupings[$k]['custom/modules/Contacts/clients/base/fields/editablelistbutton/editablelistbutton.js'] = $target;

        }
    }
}



