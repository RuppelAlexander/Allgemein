<?php
/**
 * ----------------------------------------------------------------------------
 * © ISC it & software consultants GmbH  (All rights reserved.)
 * DO NOT MODIFY THIS FILE !
 * ----------------------------------------------------------------------------
 * Author        : RuppelA
 * Create Date   : 08.09.2025
 * Change Date   : 08.09.2025
 * Main Program  : ISC LibPhoneNumber
 * Description   : zz_isc_phone_guard.php
 * ----------------------------------------------------------------------------
 * Change Log    :
 * Date        Name    Description
 * ----------------------------------------------------------------------------
 * ----------------------------------------------------------------------------
 */

$viewdefs['Contacts']['base']['layout']['record']['components'][] = ['view' => 'isc-phone-guard'];
