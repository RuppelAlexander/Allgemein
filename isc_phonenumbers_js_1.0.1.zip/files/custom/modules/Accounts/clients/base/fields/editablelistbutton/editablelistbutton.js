/**
 * ----------------------------------------------------------------------------
 * © ISC it & software consultants GmbH  (All rights reserved.)
 * DO NOT MODIFY THIS FILE !
 * ----------------------------------------------------------------------------
 * Author        : RuppelA
 * Create Date   : 30.10.2025
 * Change Date   : 30.10.2025
 * Main Program  : ISC LibPhoneNumber
 * Description   : editablelistbutton.js
 * ----------------------------------------------------------------------------
 * Change Log    :
 * Date        Name    Description
 * ----------------------------------------------------------------------------
 * ----------------------------------------------------------------------------
 */

({
    extendsFrom: 'EditablelistbuttonField',

    saveClicked: function (evt) {
        var model  = this.model || (this.context && this.context.get && this.context.get('model'));
        if (!model) return this._super('saveClicked', [evt]);

        var PHONE_FIELDS = ['phone_office','phone_alternate','phone_fax','phone_home','phone_mobile'];
        var region = 'DE';

        // Sichtbare Felder in der aktuellen Listen-Zeile
        var visibleMap = (this.view && typeof this.view.getFields === 'function')
            ? this.view.getFields(this.module, model)   // bevorzugt: wirklich gerenderte Felder dieser Row
            : null;

        // Hilfsfunktion: Anzeigename des Feldes ermitteln und übersetzen
        var self = this;
        function labelFor(field) {
            var defView = visibleMap && visibleMap[field];
            var key = defView && (defView.label || (defView.def && (defView.def.label || defView.def.vname)));
            if (!key) {
                var fdef = app.metadata.getField({module: self.module, name: field}); // Vardef
                key = fdef && (fdef.label || fdef.vname);
            }
            return key ? app.lang.get(key, self.module) : field;
        }

        function parseAndFormat(raw){
            if (!raw) return {valid:null};
            try {
                if (window.libphonenumber && typeof window.libphonenumber.parsePhoneNumberFromString === 'function'){
                    var p = window.libphonenumber.parsePhoneNumberFromString(raw, region);
                    if (!p)  return {valid:false};
                    return p.isValid() ? {valid:true, formatted:p.format('INTERNATIONAL')} : {valid:false};
                }
                if (window.libphonenumber && window.libphonenumber.PhoneNumberUtil){
                    var util = window.libphonenumber.PhoneNumberUtil.getInstance();
                    var PNF  = window.libphonenumber.PhoneNumberFormat;
                    var n = util.parseAndKeepRawInput(raw, region);
                    if (util.isValidNumber(n)) return {valid:true, formatted: util.format(n, PNF.INTERNATIONAL)};
                    return {valid:false};
                }
            } catch(e){ return {valid:false}; }
            return {valid:null}; // Bibliothek fehlt
        }

        // Nur sichtbare Telefonspalten prüfen
        var visibleNames = visibleMap ? Object.keys(visibleMap)
            : (typeof this.view.getFieldNames === 'function' ? this.view.getFieldNames(this.module) : []);
        var toCheck = _.intersection(PHONE_FIELDS, visibleNames);
        if (!toCheck.length) return this._super('saveClicked', [evt]);

        var bad = [];
        toCheck.forEach(function(f){
            var v = model.get(f);
            if (v == null || v === '') return;
            var r = parseAndFormat(v);
            if (r.valid === true) model.set(f, r.formatted);
            else if (r.valid === false) bad.push(f);
        });

        if (bad.length) {
            var labels = bad.map(labelFor);
            app.alert.show('isc_phone_warn_list_accounts', {
                level: 'warning',
                messages: 'Telefonnummer-Format nicht erkannt: ' + labels.join(', ') + '. Unverändert gespeichert.',
                autoClose: true,
                autoCloseDelay: 7000
            });
        } else if (!(window.libphonenumber)) {
            app.alert.show('isc_phone_warn_list_accounts', {
                level: 'warning',
                messages: 'Telefon-Validierung aktuell nicht möglich. Nummern unverändert gespeichert.',
                autoClose: true,
                autoCloseDelay: 7000
            });
        }

        this._super('saveClicked', [evt]);
    }
});

