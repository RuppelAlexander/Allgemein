/**
 * ----------------------------------------------------------------------------
 * © ISC it & software consultants GmbH  (All rights reserved.)
 * DO NOT MODIFY THIS FILE !
 * ----------------------------------------------------------------------------
 * Author        : RuppelA
 * Create Date   : 08.09.2025
 * Change Date   : 08.09.2025
 * Main Program  : ISC LibPhoneNumber
 * Description   : isc-phone-guard.js
 * ----------------------------------------------------------------------------
 * Change Log    :
 * Date        Name    Description
 * ----------------------------------------------------------------------------
 * ----------------------------------------------------------------------------
 */
({
    className: 'hidden',
    initialize: function(opts){
        this._super('initialize',[opts]);

        var ctx   = this.context;
        var model = ctx.get('model');
        var mod   = ctx.get('module');
        if (!model) return;

        var FIELDS = (mod === 'Contacts')
            ? ['phone_other','phone_work','phone_fax','phone_home','phone_mobile']
            : ['phone_office','phone_alternate','phone_fax','phone_home','phone_mobile'];

        // erkennt beide Lib-Varianten
        function parseAndFormat(raw, region){
            if (window.libphonenumber && typeof window.libphonenumber.parsePhoneNumberFromString === 'function'){
                var p = window.libphonenumber.parsePhoneNumberFromString(raw, region);
                return p && p.isValid() ? {valid:true, formatted:p.format('INTERNATIONAL')} : {valid:false};
            }
            if (window.libphonenumber && window.libphonenumber.PhoneNumberUtil){
                var util = window.libphonenumber.PhoneNumberUtil.getInstance();
                var PNF  = window.libphonenumber.PhoneNumberFormat;
                try {
                    var n = util.parseAndKeepRawInput(raw, region);
                    if (util.isValidNumber(n)) return {valid:true, formatted: util.format(n, PNF.INTERNATIONAL)};
                } catch(e){}
                return {valid:false};
            }
            return {valid:null}; // Lib fehlt → nicht blocken
        }

        var TASK = 'isc_phone_validate';
        if (model._validationTasks && model._validationTasks[TASK]) return;

        model.addValidationTask(TASK, function(all, errors, done){
            var region = 'DE';
            var bad = [];
            FIELDS.forEach(function(f){
                var v = model.get(f); if (!v) return;
                var r = parseAndFormat(v, region);
                if (r.valid === null) return;          // Bibliothek fehlt → keine Aktion, kein Block
                if (r.valid) model.set(f, r.formatted);
                else bad.push(f);
            });

            // Nur warnen, **keine** Fehler setzen → Save läuft durch
            if (bad.length) {
                // Duplikate dämpfen
                if (!model._iscPhoneWarnTs || Date.now() - model._iscPhoneWarnTs > 1500) {
                    app.alert.show('isc_phone_warn', {
                        level: 'warning',
                        messages: 'Telefonnummer-Format nicht erkannt: ' + bad.join(', ') + '. Unverändert gespeichert.',
                        autoclose: true
                    });
                    model._iscPhoneWarnTs = Date.now();
                }
            }
            done(null, all, errors);
        });

        this.once('dispose', function(){ model.removeValidationTask(TASK); });
    }
})


