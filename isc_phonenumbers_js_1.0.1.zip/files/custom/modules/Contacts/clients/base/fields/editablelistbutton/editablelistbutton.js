/**
 * ----------------------------------------------------------------------------
 * © ISC it & software consultants GmbH  (All rights reserved.)
 * DO NOT MODIFY THIS FILE !
 * ----------------------------------------------------------------------------
 * Author        : RuppelA
 * Create Date   : 30.10.2025
 * Change Date   : 30.10.2025
 * Main Program  :  ISC LibPhoneNumber
 * Description   : editablelistbutton.js
 * ----------------------------------------------------------------------------
 * Change Log    :
 * Date        Name    Description
 * ----------------------------------------------------------------------------
 * ----------------------------------------------------------------------------
 */

({
    extendsFrom: 'EditablelistbuttonField',

    saveClicked: function (evt) {
        var model  = this.model || (this.context && this.context.get && this.context.get('model'));
        if (!model) return this._super('saveClicked', [evt]);

        var PHONE_FIELDS = ['phone_mobile','phone_home','phone_work','phone_other','phone_fax'];
        var region = 'DE';

        // sichtbare Felder im aktuellen Row-View (Listenzeile)
        var visibleMap = (this.view && typeof this.view.getFields === 'function')
            ? this.view.getFields(this.module, model)
            : null; // Fallback unten

        // helper: Feldlabel -> sichtbarer Text in aktueller Sprache
        var self = this;
        function labelFor(field) {
            // 1) View-/Layout-Label (listenspezifisch)
            var defView = visibleMap && visibleMap[field];
            var key = defView && (defView.label || (defView.def && (defView.def.label || defView.def.vname)));

            // 2) Vardef-vname aus Modulmetadaten
            if (!key) {
                var md = app.metadata.getModule(self.module) || {};
                var fdef = md.fields && md.fields[field];
                key = fdef && (fdef.label || fdef.vname);
            }

            // 3) Übersetzen; Fallback: technischer Name
            return key ? app.lang.get(key, self.module) : field;
        }

        function parseAndFormat(raw){
            if (!raw) return {valid:null};
            try {
                if (window.libphonenumber && typeof window.libphonenumber.parsePhoneNumberFromString === 'function'){
                    var p = window.libphonenumber.parsePhoneNumberFromString(raw, region);
                    if (!p)  return {valid:false};
                    return p.isValid() ? {valid:true, formatted:p.format('INTERNATIONAL')} : {valid:false};
                }
                if (window.libphonenumber && window.libphonenumber.PhoneNumberUtil){
                    var util = window.libphonenumber.PhoneNumberUtil.getInstance();
                    var PNF  = window.libphonenumber.PhoneNumberFormat;
                    var n = util.parseAndKeepRawInput(raw, region);
                    if (util.isValidNumber(n)) return {valid:true, formatted: util.format(n, PNF.INTERNATIONAL)};
                    return {valid:false};
                }
            } catch(e){ return {valid:false}; }
            return {valid:null};
        }

        // Nur sichtbare Telefonspalten prüfen
        var visibleNames = visibleMap ? Object.keys(visibleMap)
            : (typeof this.view.getFieldNames === 'function' ? this.view.getFieldNames(this.module) : []);
        var toCheck = _.intersection(PHONE_FIELDS, visibleNames);
        if (!toCheck.length) return this._super('saveClicked', [evt]);

        var bad = [];
        toCheck.forEach(function(f){
            var v = model.get(f);
            if (v == null || v === '') return;
            var r = parseAndFormat(v);
            if (r.valid === true) model.set(f, r.formatted);
            else if (r.valid === false) bad.push(f);
        });

        if (bad.length) {
            var labels = bad.map(labelFor);
            app.alert.show('isc_phone_warn_list_contacts', {
                level: 'warning',
                messages: 'Telefonnummer-Format nicht erkannt: ' + labels.join(', ') + '. Unverändert gespeichert.',
                autoClose: true,
                autoCloseDelay: 7000

            });
        } else if (!(window.libphonenumber)) {
            app.alert.show('isc_phone_warn_list_contacts', {
                level: 'warning',
                messages: 'Telefon-Validierung aktuell nicht möglich. Nummern unverändert gespeichert.',
                autoClose: true,
                autoCloseDelay: 7000

            });
        }

        this._super('saveClicked', [evt]);
    }
});


