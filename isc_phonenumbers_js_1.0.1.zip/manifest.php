<?php
/**
 * ----------------------------------------------------------------------------
 * © ISC it & software consultants GmbH  (All rights reserved.)
 * DO NOT MODIFY THIS FILE !
 * ----------------------------------------------------------------------------
 * Author        : RuppelA
 * Create Date   : 26.08.2023
 * Change Date   :
 * Main Program  : ISC LibPhoneNumber
 * Description   :
 * ----------------------------------------------------------------------------
 * Change Log    :
 * Date        Name    Description
 * ----------------------------------------------------------------------------
 * ----------------------------------------------------------------------------
 */
$manifest = [
    'name' => 'ISC LibPhoneNumber (JS sources only)',
    'description' => 'Liefert libphonenumber-JavaScript-Quellen und Lizenzen. Keine Aktivierung.',
    'type' => 'module',
    'version' => '1.0.1',
    'is_uninstallable' => true,
    'remove_tables' => 'prompt',
    'author' => 'Alexander Ruppel',
    'acceptable_sugar_versions' => ['regex_matches' => ['^25\\..*','^14\\..*','^13\\..*']],
    'acceptable_sugar_flavors' => ['PRO','ENT','ULT'],
];

$installdefs = [
    'id' => 'isc_libphonenumber',
    'copy' => [
        // kompletter JS-Ordner
        [
            'from' => '<basepath>/files/custom/include/isc_libphonenumber/phonenumbers/',
            'to'   => 'custom/include/isc_libphonenumber/phonenumbers/',
        ],
        // Lizenzen mitliefern
        [
            'from' => '<basepath>/files/custom/third_party/libphonenumber/',
            'to'   => 'custom/third_party/libphonenumber/',
        ],
        [
            'from' => '<basepath>/files/custom/Extension/application/Ext/JSGroupings/isc_libphonenumber.php',
            'to'   => 'custom/Extension/application/Ext/JSGroupings/isc_libphonenumber.php',

        ],
        [
            'from' => '<basepath>/files/custom/modules/Contacts/clients/base/views/isc-phone-guard/isc-phone-guard.js',
            'to'   => 'custom/modules/Contacts/clients/base/views/isc-phone-guard/isc-phone-guard.js',

        ],
        [
            'from' => '<basepath>/files/custom/Extension/modules/Contacts/Ext/clients/base/layouts/record/zz_isc_phone_guard.php',
            'to'   => 'custom/Extension/modules/Contacts/Ext/clients/base/layouts/record/zz_isc_phone_guard.php',

        ],
        [
            'from' => '<basepath>/files/custom/Extension/modules/Accounts/Ext/clients/base/layouts/record/zz_isc_phone_guard.php',
            'to'   => 'custom/Extension/modules/Accounts/Ext/clients/base/layouts/record/zz_isc_phone_guard.php',

        ],
        [
            'from' => '<basepath>/files/custom/modules/Accounts/clients/base/views/isc-phone-guard/isc-phone-guard.js',
            'to'   => 'custom/modules/Accounts/clients/base/views/isc-phone-guard/isc-phone-guard.js',

        ],
        [
            'from' => '<basepath>/files/custom/modules/Accounts/clients/base/fields/editablelistbutton/editablelistbutton.js',
            'to'   => 'custom/modules/Accounts/clients/base/fields/editablelistbutton/editablelistbutton.js',

        ],
        [
            'from' => '<basepath>/files/custom/modules/Contacts/clients/base/fields/editablelistbutton/editablelistbutton.js',
            'to'   => 'custom/modules/Contacts/clients/base/fields/editablelistbutton/editablelistbutton.js',

        ],




    ],
];