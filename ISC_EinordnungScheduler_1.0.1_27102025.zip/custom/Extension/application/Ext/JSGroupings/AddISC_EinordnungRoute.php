<?php
/**
 * ----------------------------------------------------------------------------
 * © ISC it & software consultants GmbH  (All rights reserved.)
 * DO NOT MODIFY THIS FILE !
 * ----------------------------------------------------------------------------
 * Author        : RuppelA
 * Main Program  : ISC_EinordnungScheduler
 * Description   : JS-Grouping für Route/Drawer
 * ----------------------------------------------------------------------------
 */
// Pfad: custom/Extension/application/Ext/JSGroupings/AddISC_EinordnungRoute.php

foreach ($js_groupings as $key => $groupings) {
    foreach ($groupings as $file => $target) {
        if ($target == 'include/javascript/sugar_grp7.min.js') {
            $js_groupings[$key]['custom/javascript/isc-einordnung-drawer-open.js']
                = 'include/javascript/sugar_grp7.min.js';
        }
    }
}


