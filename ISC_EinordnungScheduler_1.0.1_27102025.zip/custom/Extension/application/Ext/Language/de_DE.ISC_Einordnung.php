<?php
/**
 * ----------------------------------------------------------------------------
 * © ISC it & software consultants GmbH  (All rights reserved.)
 * DO NOT MODIFY THIS FILE !
 * ----------------------------------------------------------------------------
 * Author        : RuppelA
 * Create Date   : 23.10.2025
 * Change Date   : 23.10.2025
 * Main Program  : ISC_EinordnungScheduler
 * Description   : de_DE.ISC_Einordnung.php
 * ----------------------------------------------------------------------------
 * Change Log    :
 * Date        Name    Description
 * ----------------------------------------------------------------------------
 * ----------------------------------------------------------------------------
 */
// Pfad: custom/Extension/application/Ext/Language/de_DE.ISC_Einordnung.php
$app_strings['LBL_ISC_EINORDNUNG_TITLE'] = 'ISC Einordnung – Einstellungen';
$app_strings['LBL_ISC_EINORDNUNG_DESC']  = 'Schwellen (Monate), Event-Fenster (Tage) und Dry-Run konfigurieren.';
$app_strings['LBL_ISC_THRESHOLDS']      = 'Schwellen zu „Ruhend“ (Monate je Status)';
$app_strings['LBL_ISC_NEWKONTAKT']      = 'Neukontakt (Monate)';
$app_strings['LBL_ISC_INTERESSENT']     = 'Interessent (Monate)';
$app_strings['LBL_ISC_ANBAHNUNG']       = 'Anbahnungsphase (Monate)';
$app_strings['LBL_ISC_AKTIV']           = 'Aktiv (Monate)';
$app_strings['LBL_ISC_RECENT']          = 'Event-Fenster in Tagen (0 = immer erlauben)';
$app_strings['LBL_ISC_DRYRUN']          = 'Dry-Run (nur loggen, nichts speichern)';
$app_strings['LBL_ISC_SAVE']            = 'Speichern';
$app_strings['LBL_ISC_SAVED']           = 'Einstellungen gespeichert.';
$app_strings['LBL_ISC_LOAD_FAILED']     = 'Einstellungen konnten nicht geladen werden.';
$app_strings['LBL_ISC_SAVE_FAILED']     = 'Einstellungen konnten nicht gespeichert werden.';
$app_strings['LBL_ISC_DRY_EVENT_WHEN']       = 'Dry-Run: Opp.-Änderungsdatum (Override)';
$app_strings['LBL_ISC_DRY_ACC_CHANGED_AT']   = 'Dry-Run: Account-Statusdatum (Override)';
