<?php
/**
 * ----------------------------------------------------------------------------
 * © ISC it & software consultants GmbH  (All rights reserved.)
 * DO NOT MODIFY THIS FILE !
 * ----------------------------------------------------------------------------
 * Author        : RuppelA
 * Create Date   : 27.10.2025
 * Change Date   : 27.10.2025
 * Main Program  : ISC_EinordnungScheduler
 * Description   : en_US.ISC_Einordnung.php
 * ----------------------------------------------------------------------------
 * Change Log    :
 * Date        Name    Description
 * ----------------------------------------------------------------------------
 * ----------------------------------------------------------------------------
 */

// Pfad: custom/Extension/application/Ext/Language/en_US.ISC_Einordnung.php

$app_strings['LBL_ISC_EINORDNUNG_TITLE'] = 'ISC Classification – Settings';
$app_strings['LBL_ISC_EINORDNUNG_DESC']  = 'Configure thresholds (months), event window (days), and dry run.';
$app_strings['LBL_ISC_THRESHOLDS']      = 'Thresholds to "Dormant" (months per status)';
$app_strings['LBL_ISC_NEWKONTAKT']      = 'New Contact (months)';
$app_strings['LBL_ISC_INTERESSENT']     = 'Prospect (months)';
$app_strings['LBL_ISC_ANBAHNUNG']       = 'Initiation Phase (months)';
$app_strings['LBL_ISC_AKTIV']           = 'Active (months)';
$app_strings['LBL_ISC_RECENT']          = 'Event window in days (0 = always allow)';
$app_strings['LBL_ISC_DRYRUN']          = 'Dry run (log only, do not save)';
$app_strings['LBL_ISC_SAVE']            = 'Save';
$app_strings['LBL_ISC_SAVED']           = 'Settings saved.';
$app_strings['LBL_ISC_LOAD_FAILED']     = 'Failed to load settings.';
$app_strings['LBL_ISC_SAVE_FAILED']     = 'Failed to save settings.';
$app_strings['LBL_ISC_DRY_EVENT_WHEN']       = 'Dry run: Opportunity change date (override)';
$app_strings['LBL_ISC_DRY_ACC_CHANGED_AT']   = 'Dry run: Account status change date (override)';