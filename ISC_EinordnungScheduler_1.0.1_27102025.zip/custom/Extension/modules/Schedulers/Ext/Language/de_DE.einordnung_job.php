<?php
/**
 * ----------------------------------------------------------------------------
 * © ISC it & software consultants GmbH  (All rights reserved.)
 * DO NOT MODIFY THIS FILE !
 * ----------------------------------------------------------------------------
 * Author        : RuppelA
 * Create Date   : 10.10.2025
 * Change Date   : 10.10.2025
 * Main Program  : ISC_EinordnungScheduler
 * Description   : de_DE.einordnung_job.php
 * ----------------------------------------------------------------------------
 * Change Log    :
 * Date        Name    Description
 * ----------------------------------------------------------------------------
 * ----------------------------------------------------------------------------
 */

// Pfad: custom/Extension/modules/Schedulers/Ext/Language/de_DE.einordnung_job.php

$mod_strings['LBL_JOBSETEINORDNUNGBYSCHEDULER'] = 'Geschäftspartner-Einordnung';
$mod_strings['LBL_JOBSETEINORDNUNGBYSCHEDULER'] ='Setzt Geschäftspartner-Status nach Zeit & Bauprojekte-Phase.';
