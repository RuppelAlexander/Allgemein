<?php
/**
 * ----------------------------------------------------------------------------
 * © ISC it & software consultants GmbH  (All rights reserved.)
 * DO NOT MODIFY THIS FILE !
 * ----------------------------------------------------------------------------
 * Author        : RuppelA
 * Create Date   : 10.10.2025
 * Change Date   : 10.10.2025
 * Main Program  : ISC_EinordnungScheduler
 * Description   : en_us.einordnung_job.php
 * ----------------------------------------------------------------------------
 * Change Log    :
 * Date        Name    Description
 * ----------------------------------------------------------------------------
 * ----------------------------------------------------------------------------
 */


// custom/Extension/modules/Schedulers/Ext/Language/en_us.einordnung_job.php


$mod_strings['LBL_JOBSETEINORDNUNGBYSCHEDULER'] = 'Account Classification';
$mod_strings['LB_JOBSETEINORDNUNGBYSCHEDULER_DESCRIPTION'] = 'Sets account status by time & project stage.';
