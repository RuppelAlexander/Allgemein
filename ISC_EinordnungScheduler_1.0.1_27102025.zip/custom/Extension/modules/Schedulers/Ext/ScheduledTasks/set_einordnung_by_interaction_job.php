<?php
/**
 * ----------------------------------------------------------------------------
 * © ISC it & software consultants GmbH  (All rights reserved.)
 * DO NOT MODIFY THIS FILE !
 * ----------------------------------------------------------------------------
 * Author        : RuppelA
 * Create Date   : 10.10.2025
 * Change Date   : 10.10.2025
 * Main Program  : ISC_EinordnungScheduler
 * Description   : set_einordnung_by_interaction_job.php
 * ----------------------------------------------------------------------------
 * Change Log    :
 * Date        Name    Description
 * ----------------------------------------------------------------------------
 * ----------------------------------------------------------------------------
 */

// Pfad: custom/Extension/modules/Schedulers/Ext/ScheduledTasks/set_einordnung_by_interaction_job.php

$job_strings[] = 'jobSetEinordnungByScheduler';

/**
 * Scheduler-Job
 * - Setzt Accounts.einordnung_dropdown_c anhand von last_interaction_date (Zeitregeln)
 *   und verknüpften Opportunities.sales_stage.
 * - Produktionsmodus: Minutenwerte auf Monate/Jahre hochsetzen.
 */
function jobSetEinordnungByScheduler(): bool
{
    try {
        $cfg = EinordnungSchedulerConfig::fromAdmin();
        $runner = new EinordnungSchedulerRunner($cfg);
        $runner->processAccounts();
        return true;
    } catch (\Throwable $e) {
        $GLOBALS['log']->fatal('ISC_EinordnungScheduler: Unhandled: '.$e->getMessage());
        return false;
    }
}

/**
 * Konfiguration.
 */
final class EinordnungSchedulerConfig
{
    /** Feldnamen */
    public string $FIELD_STATUS = 'einordnung_dropdown_c';
    public string $FIELD_LAST_INTERACTION = 'last_interaction_date';
    public ?string $DRY_EVENT_WHEN_RAW = null;
    public ?string $DRY_ACC_CHANGED_AT_RAW = null;

    /** Opportunity-Felder/Listen */
    public string $OPP_STAGE_FIELD = 'sales_stage';
    public string $OPP_STAGE_AUFTRAG = 'Auftrag';
    public string $OPP_STAGE_AUSSCHREIBUNG = 'Ausschreibung';
    public string $LOG_PREFIX = 'ISC_EinordnungScheduler';
    public bool $LOG_CHANGES = true; 
    public bool $DRY_RUN = false;

    /** Batchgröße */
    public int $BATCH = 300;

    /**
     * Zeit-Schwellen in MINUTEN für den Wechsel → „Ruhend“.
     * Schlüssel = aktueller Status in einordnung_dropdown_c.
     */
    public array $DORMANT_THRESHOLDS_MIN = [
        'Neukontakt'      => 43200 * 6,   
        'Interessent'     => 43200 * 12,
        'Anbahnungsphase' => 43200 * 12,
        'Aktiv'           => 43200 * 36,
    ];

    /** Manuelle Stati, die nie automatisch überschrieben werden */
    public array $STATUS_MANUAL_LOCK = ['Inaktiv', 'Uninteressant'];

    /** Zielwerte */
    public string $STATUS_INT   = 'Interessent';
    public string $STATUS_ANB   = 'Anbahnungsphase';
    public string $STATUS_AKTIV = 'Aktiv';
    public string $STATUS_RUH   = 'Ruhend';

    /** Ereignisse nur anwenden, wenn letzte Interaktion innerhalb dieses Fensters liegt (Minuten) */
    public int $RECENT_OVERRIDE_MIN =  0; //10080; // 7 Tage

    public static function fromAdmin(): self
    {
        $s = new self();

        $admin = \BeanFactory::newBean('Administration');
        $admin->retrieveSettings('isc_einordnung');

        // Helper: int >= 0
        $get = function (string $key, int $def = 0) use ($admin): int {
            return max(0, (int)($admin->settings[$key] ?? $def));
        };

        // Monate -> Minuten, Tage -> Minuten
        $monthMin = 30 * 24 * 60;
        $dayMin   = 24 * 60;

        $ncM   = $get('isc_einordnung_threshold_new_contact_months', 6);
        $intM  = $get('isc_einordnung_threshold_interessent_months', 12);
        $anbM  = $get('isc_einordnung_threshold_anbahnungsphase_months', 12);
        $aktM  = $get('isc_einordnung_threshold_aktiv_months', 36);
        $recentD = $get('isc_einordnung_recent_override_days', 0);
        $dryRun  = $get('isc_einordnung_dry_run', 0) ? true : false;

        $s->DORMANT_THRESHOLDS_MIN = [
            'Neukontakt'      => $ncM  * $monthMin,
            'Interessent'     => $intM * $monthMin,
            'Anbahnungsphase' => $anbM * $monthMin,
            'Aktiv'           => $aktM * $monthMin,
        ];
        $s->RECENT_OVERRIDE_MIN = $recentD * $dayMin; // 0 => Events immer erlaubt
        $s->DRY_RUN = $dryRun;

        // NEU: Dry-Run Overrides (als DB-String "YYYY-MM-DD HH:MM:SS" oder leer)
        $s->DRY_EVENT_WHEN_RAW     = (string)($admin->settings['isc_einordnung_dry_event_when'] ?? '') ?: null;
        $s->DRY_ACC_CHANGED_AT_RAW = (string)($admin->settings['isc_einordnung_dry_account_changed_at'] ?? '') ?: null;


        return $s;
    }



    public static function prodDefaults(): self
    {
        $s = new self();
        // Monate → Minuten (vereinfachend 30 Tage/Monat)
        $month = 30 * 24 * 60;      // 43.200
        $year  = 12 * $month;       // 518.400

        $s->DORMANT_THRESHOLDS_MIN = [
            'Neukontakt'      => 6 * $month,   // ~ 6 Monate
            'Interessent'     => 1 * $year,    // 12 Monate
            'Anbahnungsphase' => 1 * $year,    // 12 Monate
            'Aktiv'           => 3 * $year,    // 36 Monate
        ];
        $s->RECENT_OVERRIDE_MIN = 0; //10080; // 7 Tage
        return $s;
    }
}

/**
 * Ausführungslogik.
 */
final class EinordnungSchedulerRunner
{
    public function __construct(private EinordnungSchedulerConfig $cfg)
    {
    }

    private function parseDb(?string $raw): ?\SugarDateTime
    {
        if (!$raw) { return null; }
        $td = \TimeDate::getInstance();
        $dt = $td->fromDb($raw);
        if ($dt instanceof \SugarDateTime) { return $dt; }
        // Fallback: reines Datum (YYYY-MM-DD)
        $dt = \SugarDateTime::createFromFormat('Y-m-d H:i:s', $raw.' 00:00:00', new \DateTimeZone('UTC'));
        return $dt ?: null;
    }

    private function maxDt(?\SugarDateTime $a, ?\SugarDateTime $b): ?\SugarDateTime
    {
        if ($a && $b) { return ((int)$a->format('U') >= (int)$b->format('U')) ? $a : $b; }
        return $a ?: $b;
    }

    private function getAccountStatusChangedAt(string $accountId, string $status): ?\SugarDateTime
    {
        // letztes Audit-Datum für den AKTUELLEN Statuswert
        $db = \DBManagerFactory::getInstance();
        $sql = sprintf(
            "SELECT date_created FROM accounts_audit
         WHERE parent_id=%s AND field_name='einordnung_dropdown_c' AND after_value_string=%s
         ORDER BY date_created DESC LIMIT 1",
            $db->quoted($accountId),
            $db->quoted($status)
        );
        $dt = $db->getOne($sql);
        return $dt ? \TimeDate::getInstance()->fromDb($dt) : null;
    }

    private function shouldBecomeDormantWithBaseline(string $currentStatus, ?\SugarDateTime $baseline, \SugarDateTime $now): bool
    {
        if (!isset($this->cfg->DORMANT_THRESHOLDS_MIN[$currentStatus])) { return false; }
        if (!$baseline) { return false; } // kein Datum ⇒ kein Ruhend
        $diffSec = max(0, (int)$now->format('U') - (int)$baseline->format('U'));
        $diffMin = (int) floor($diffSec / 60);
        return $diffMin >= (int)$this->cfg->DORMANT_THRESHOLDS_MIN[$currentStatus];
    }

    private function logInfo($m){ $GLOBALS['log']->warning($this->cfg->LOG_PREFIX.': '.$m); }

    public function processAccounts(): void
    {
        $this->logInfo('Start');

        $offset = 0;
        $td  = \TimeDate::getInstance();
        $now = $td->getNow(true); // UTC

        // Dry-Run-Overrides einmalig parsen
        $ovrEvent = $this->parseDb($this->cfg->DRY_EVENT_WHEN_RAW);
        $ovrAcc   = $this->parseDb($this->cfg->DRY_ACC_CHANGED_AT_RAW);

        while (true) {
            $rows = $this->fetchAccountBatch($offset, $this->cfg->BATCH);
            if (empty($rows)) { break; }

            foreach ($rows as $row) {
                $bean = \BeanFactory::retrieveBean('Accounts', $row['id'], ['disable_row_level_security' => true]);
                if (!$bean) { continue; }

                $current = (string)($bean->{$this->cfg->FIELD_STATUS} ?? '');
                $lastRaw = (string)($bean->{$this->cfg->FIELD_LAST_INTERACTION} ?? '');

                // 0) Manuelle Sperre
                if (in_array($current, $this->cfg->STATUS_MANUAL_LOCK, true)) {
                    if ($this->cfg->DRY_RUN) {
                        $this->logInfo("DRY RUN | Account {$bean->id} | skip (manuell gesperrt) | status={$current}");
                    }
                    continue;
                }

                // Schwelle in Minuten für den aktuellen Status (Fallback: Aktiv)
                $thrMin = (int)($this->cfg->DORMANT_THRESHOLDS_MIN[$current]
                    ?? $this->cfg->DORMANT_THRESHOLDS_MIN[$this->cfg->STATUS_AKTIV]
                    ?? 0);

                // 1) Baseline für Ruhend: max(Status-Audit-ChangeDate, last_interaction_date)
                $lastDt = $this->parseDb($lastRaw); // SugarDateTime|null

                $statusChangedAt = $this->getAccountStatusChangedAt($bean->id, $current); // SugarDateTime|null
                if ($this->cfg->DRY_RUN && $ovrAcc instanceof \SugarDateTime) {
                    $statusChangedAt = $ovrAcc; // Account-Audit-Datum simulieren
                }

                $baseline    = $this->maxDt($statusChangedAt, $lastDt); // SugarDateTime|null
                $baselineStr = $baseline ? $td->asDb($baseline) : 'NULL';

                // 2) Event (Opp-Stage 'Auftrag'/'Ausschreibung') mit Zeitstempel (Audit bevorzugt)
                $event = $this->detectEventForAccount($bean->id); // ['target','when']|null
                if ($event && $this->cfg->DRY_RUN && $ovrEvent instanceof \SugarDateTime) {
                    $event['when'] = $ovrEvent; // Opp-Change-Date simulieren
                }

                // 2a) Event-Priorität: Event jünger als Schwelle des aktuellen Status
                $applyEvent  = false;
                $ageEventMin = null;
                if ($event && $event['when'] instanceof \SugarDateTime && $thrMin > 0) {
                    $ageEventMin = (int) floor(((int)$now->format('U') - (int)$event['when']->format('U')) / 60);
                    $applyEvent  = ($ageEventMin <= $thrMin) && ($event['target'] !== $current);
                }

                if ($applyEvent) {
                    $this->logInfo(sprintf(
                        "%sAccount %s | %s → %s | Grund=Event | eventWhen=%s | thrMin=%s",
                        $this->cfg->DRY_RUN ? "DRY RUN | " : "",
                        $bean->id,
                        $current,
                        $event['target'],
                        $td->asDb($event['when']),
                        (string)$thrMin
                    ));
                    $this->saveIfChanged($bean, $event['target'], $current, $lastRaw);
                    continue;
                }

                // 3) Zeitregel „Ruhend“ gegen Baseline
                $becomeDormant = false;
                $ageMinDorm    = null;
                $alreadyDormant = false;
                if ($baseline instanceof \SugarDateTime && $thrMin > 0) {
                    $diffSec     = max(0, (int)$now->format('U') - (int)$baseline->format('U'));
                    $ageMinDorm  = (int) floor($diffSec / 60);
                    $becomeDormant = $ageMinDorm >= $thrMin;
                }

                // Wenn Ruhend fällig, aber schon Ruhend → nichts ändern, nur später begründen
                if ($becomeDormant) {
                    if ($current === $this->cfg->STATUS_RUH) {
                        $alreadyDormant = true; // markiere nur, kein Log „Ruhend → Ruhend“ und kein Save
                    } else {
                        $this->logInfo(sprintf(
                            "%sAccount %s | %s → %s | Grund=Zeitregel | baseline=%s | thrMin=%s",
                            $this->cfg->DRY_RUN ? "DRY RUN | " : "",
                            $bean->id,
                            $current,
                            $this->cfg->STATUS_RUH,
                            $baselineStr,
                            (string)$thrMin
                        ));
                        $this->saveIfChanged($bean, $this->cfg->STATUS_RUH, $current, $lastRaw);
                        continue;
                    }
                }

                // 4) Begründungs-Log bei keiner Änderung (immer)
                {
                    $reasons   = [];
                    $evtWhenStr = 'NULL';

                    // Event-Gründe
                    if (!$event) {
                        $reasons[] = 'kein Event';
                    } else {
                        if ($event['when'] instanceof \SugarDateTime) {
                            $evtWhenStr  = $td->asDb($event['when']);
                            $ageEventMin = $ageEventMin ?? (int) floor(((int)$now->format('U') - (int)$event['when']->format('U')) / 60);
                            if ($event['target'] === $current) {
                                $reasons[] = 'Event-Ziel==aktueller Status';
                            } elseif ($thrMin > 0 && $ageEventMin > $thrMin) {
                                $reasons[] = "Event zu alt ({$ageEventMin}/{$thrMin} min)";
                            } else {
                                $reasons[] = 'Event-Bedingungen nicht erfüllt';
                            }
                        } else {
                            $reasons[] = 'Event ohne Zeitstempel';
                        }
                    }

                    // Ruhend-Gründe
                    if (!$baseline) {
                        $reasons[] = 'Baseline leer';
                    } else {
                        if ($thrMin <= 0) {
                            $reasons[] = 'keine Schwelle konfiguriert';
                        } else {
                            $ageMinDorm = $ageMinDorm ?? (int) floor(((int)$now->format('U') - (int)$baseline->format('U')) / 60);
                            if ($ageMinDorm < $thrMin) {
                                $reasons[] = "unter Schwelle ({$ageMinDorm}/{$thrMin} min)";
                            }
                        }
                    }

                    $this->logInfo(sprintf(
                        "Account %s | keine Änderung | status=%s | baseline=%s | eventWhen=%s | Gründe=%s",
                        $bean->id,
                        $current,
                        $baselineStr,
                        $evtWhenStr,
                        $reasons ? implode('; ', $reasons) : '—'
                    ));
                }
            }

            $offset += $this->cfg->BATCH;
        }

        $this->logInfo('Ende');
    }

    



    /**********************************************************
     * Liefert letztes relevantes Opp-Event für Account:
     * - Auftrag  -> target = STATUS_AKTIV
     * - Ausschreibung -> target = STATUS_ANB
     * 'when' = Audit-Wechsel auf Stage, Fallback: date_modified
     **********************************************************/
    private function detectEventForAccount(string $accountId): ?array
    {
        $td  = \TimeDate::getInstance();
        $opp = \BeanFactory::newBean('Opportunities');

        $sq = new \SugarQuery();
        $sq->distinct(true);
        $sq->from($opp, ['team_security' => false]);
        $sq->select(['id', $this->cfg->OPP_STAGE_FIELD, 'date_modified']);

        $join = $sq->joinTable('accounts_opportunities', ['alias' => 'ao', 'joinType' => 'INNER']);
        $join->on()
            ->equalsField('ao.opportunity_id', 'opportunities.id')
            ->equals('ao.account_id', $accountId)
            ->equals('ao.deleted', 0);

        $sq->where()
            ->equals('opportunities.deleted', 0)
            ->in($this->cfg->OPP_STAGE_FIELD, [
                $this->cfg->OPP_STAGE_AUFTRAG,
                $this->cfg->OPP_STAGE_AUSSCHREIBUNG
            ]);

        $sq->limit(500);
        $rows = $sq->execute();
        if (empty($rows)) { return null; }

        $ids = array_column($rows, 'id');

        $getLatest = function (array $rows, array $ids, string $stage) use ($td) : ?\SugarDateTime {
            $db = \DBManagerFactory::getInstance();
            if (!empty($ids)) {
                $in = implode("','", array_map([$db, 'quote'], $ids));
                $sql = "
                SELECT date_created
                FROM opportunities_audit
                WHERE field_name = 'sales_stage'
                  AND after_value_string = " . $db->quoted($stage) . "
                  AND parent_id IN ('{$in}')
                ORDER BY date_created DESC
                LIMIT 1";
                $dt = $db->getOne($sql);
                if ($dt) {
                    $d = $td->fromDb($dt);
                    if ($d instanceof \SugarDateTime) { return $d; }
                }
            }
            // Fallback: neuestes date_modified in dieser Stage
            $latest = null;
            foreach ($rows as $r) {
                if ((string)$r[$this->cfg->OPP_STAGE_FIELD] !== $stage) { continue; }
                $dm = $td->fromDb($r['date_modified']);
                if ($dm instanceof \SugarDateTime) {
                    if (!$latest || (int)$dm->format('U') > (int)$latest->format('U')) { $latest = $dm; }
                }
            }
            return $latest;
        };

        $whenAuf = $getLatest($rows, $ids, $this->cfg->OPP_STAGE_AUFTRAG);
        $whenAus = $getLatest($rows, $ids, $this->cfg->OPP_STAGE_AUSSCHREIBUNG);

        // Neu: nimm das jüngere Event
        if ($whenAuf && $whenAus) {
            if ((int)$whenAuf->format('U') >= (int)$whenAus->format('U')) {
                return ['target' => $this->cfg->STATUS_AKTIV, 'when' => $whenAuf];
            } else {
                return ['target' => $this->cfg->STATUS_ANB, 'when' => $whenAus];
            }
        }
        if ($whenAuf) { return ['target' => $this->cfg->STATUS_AKTIV, 'when' => $whenAuf]; }
        if ($whenAus) { return ['target' => $this->cfg->STATUS_ANB,  'when' => $whenAus]; }
        return null;
    }

    private function isEventNewerOrNoInteraction($eventWhen, string $lastRaw): bool
    {
        if ($lastRaw === '') { return true; }
        $td = \TimeDate::getInstance();
        $last = $td->fromDb($lastRaw) ?: \SugarDateTime::createFromFormat('Y-m-d H:i:s', $lastRaw.' 00:00:00', new \DateTimeZone('UTC'));
        if (!$last instanceof \SugarDateTime) { return true; }
        if (!$eventWhen instanceof \SugarDateTime) { return false; }
        return (int)$eventWhen->format('U') >= (int)$last->format('U');
    }

    private function hasRecentInteraction(string $lastRaw, \SugarDateTime $now, int $minutes): bool
    {
        if ($lastRaw === '') { return false; }
        $td = \TimeDate::getInstance();
        $dt = $td->fromDb($lastRaw) ?: \SugarDateTime::createFromFormat('Y-m-d H:i:s', $lastRaw.' 00:00:00', new \DateTimeZone('UTC'));
        if (!$dt instanceof \SugarDateTime) { return false; }
        $diffSec = max(0, (int)$now->format('U') - (int)$dt->format('U'));
        return (int)floor($diffSec / 60) <= $minutes;
    }

    private function fetchAccountBatch(int $offset, int $limit): array
    {
        $sq = new \SugarQuery();
        $sq->distinct(true);
        $sq->from(\BeanFactory::newBean('Accounts'), ['team_security' => false]);
        $sq->select(['id', $this->cfg->FIELD_STATUS, $this->cfg->FIELD_LAST_INTERACTION]);

        $where = $sq->where();
        $where->equals('accounts.deleted', 0);

        $sq->orderBy('accounts.id', 'ASC');
        $sq->limit($limit);
        $sq->offset($offset);

        return $sq->execute();
    }

    private function saveIfChanged(\SugarBean $bean, string $new, ?string $old=null, ?string $lastRaw=null): void
    {
        $field = $this->cfg->FIELD_STATUS;
        $old ??= (string)($bean->$field ?? '');
        if ($old === $new) { return; }
        if ($this->cfg->LOG_CHANGES) {
            $this->logInfo("Account {$bean->id} | {$bean->name} : {$old} -> {$new} | letzteInteraktion={$lastRaw}");
        }
        if ($this->cfg->DRY_RUN) { return; }
        $bean->$field = $new;
        $bean->updateCalculatedFields = false;
        $bean->save();
    }

    /**
     * Zeitbasierte Regel: true → Status soll „Ruhend“ werden.
     */
    private function shouldBecomeDormant(string $currentStatus, string $lastRaw, \SugarDateTime $now): bool
    {
        if (!isset($this->cfg->DORMANT_THRESHOLDS_MIN[$currentStatus])) {
            return false;
        }

        // Kein Datum → KEIN Ruhend
        if ($lastRaw === '') {
            return false;
        }

        $td = \TimeDate::getInstance();
        $dt = $td->fromDb($lastRaw);

        // Fallback: reines Datum
        if (!$dt instanceof \SugarDateTime) {
            $dt = \SugarDateTime::createFromFormat('Y-m-d H:i:s', $lastRaw . ' 00:00:00', new \DateTimeZone('UTC'));
            if (!$dt) {
                return false;
            }
        }

        $diffSec = max(0, (int)$now->format('U') - (int)$dt->format('U'));
        $diffMin = (int) floor($diffSec / 60);

        return $diffMin >= (int)$this->cfg->DORMANT_THRESHOLDS_MIN[$currentStatus];
    }

       /**
     * Ereignisziele aus Opportunities:
     * - Mindestens eine Opportunity mit sales_stage = 'Auftrag' → „Aktiv“
     * - Sonst mind. eine mit 'Ausschreibung' → „Anbahnungsphase“
     */
    private function detectEventTargetFromOpportunities(string $accountId): ?string
    {
        $sq = new \SugarQuery();
        $opp = \BeanFactory::newBean('Opportunities');
        $sq->from($opp, ['team_security' => false]);
        $sq->select([$this->cfg->OPP_STAGE_FIELD]);

        // Join zur Beziehungs-Tabelle
        $join = $sq->joinTable('accounts_opportunities', ['alias' => 'ao', 'joinType' => 'INNER']);
        $join->on()
            ->equalsField('ao.opportunity_id', 'opportunities.id')
            ->equals('ao.account_id', $accountId)
            ->equals('ao.deleted', 0);

        $sq->where()
            ->equals('opportunities.deleted', 0)
            ->in($this->cfg->OPP_STAGE_FIELD, [$this->cfg->OPP_STAGE_AUFTRAG, $this->cfg->OPP_STAGE_AUSSCHREIBUNG]);

        $sq->limit(500);
        $rows = $sq->execute();
        if (empty($rows)) {
            return null;
        }

        $hasAuftrag = false;
        $hasAussch = false;
        foreach ($rows as $r) {
            $stage = (string)$r[$this->cfg->OPP_STAGE_FIELD];
            if ($stage === $this->cfg->OPP_STAGE_AUFTRAG) {
                $hasAuftrag = true;
                break;
            }
            if ($stage === $this->cfg->OPP_STAGE_AUSSCHREIBUNG) {
                $hasAussch = true;
            }
        }

        if ($hasAuftrag) {
            return $this->cfg->STATUS_AKTIV;
        }
        if ($hasAussch) {
            return $this->cfg->STATUS_ANB;
        }
        return null;
    }
}
