<?php
/**
 * ----------------------------------------------------------------------------
 * © ISC it & software consultants GmbH  (All rights reserved.)
 * DO NOT MODIFY THIS FILE !
 * ----------------------------------------------------------------------------
 * Author        : RuppelA
 * Create Date   : 23.10.2025
 * Change Date   : 23.10.2025
 * Main Program  : ISC_EinordnungScheduler
 * Description   : isc-einordnung-drawer.php
 * ----------------------------------------------------------------------------
 * Change Log    :
 * Date        Name    Description
 * ----------------------------------------------------------------------------
 * ----------------------------------------------------------------------------
 */
// Pfad: custom/clients/base/layouts/isc-einordnung-drawer/isc-einordnung-drawer.php

$viewdefs['base']['layout']['isc-einordnung-drawer']=[
    'type'=>'simple',
    'components'=>[
        ['view'=>'isc-einordnung-drawer']
    ]
];
