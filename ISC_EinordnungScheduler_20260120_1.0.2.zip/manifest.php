<?php
/**
 * ----------------------------------------------------------------------------
 * © ISC it & software consultants GmbH  (All rights reserved.)
 * DO NOT MODIFY THIS FILE !
 * ----------------------------------------------------------------------------
 * Author        : RuppelA
 * Create Date   : 10.10.2025
 * Change Date   : 27.10.2025
 * Main Program  : ISC_EinordnungScheduler
 * Description   :
 *  - Scheduler "jobSetEinordnungByScheduler" setzt Accounts.einordnung_dropdown_c per Zeit- und Ereignisregeln.
 *  - Admin-Panel (Administration) zum Konfigurieren von Schwellen, Event-Fenster und Dry-Run.
 * 20.01.2026 AR  -Das Paket an Kunden bedürfnisse angepasst/erweitert
 * ----------------------------------------------------------------------------
 */

$manifest = array(
    'name' => 'ISC_EinordnungScheduler',
    'version' => '1.0.2',
    'key' => 'ISC',
    'author' => 'Alexander Ruppel',
    'published_date' => '2025-10-27',
    'description' => 'Scheduler + Admin-Panel + Drawer + REST-API für Einordnung',
    'type' => 'module',
    'remove_tables' => 'prompt',
    'is_uninstallable' => true,
    'acceptable_sugar_versions' => array(
        'regex_matches' => array('^25\\..*')
    ),
    'acceptable_sugar_flavors'  => array('ENT', 'ULT', 'CORP', 'PRO'),
);

$installdefs = array(
    'id' => 'ISC_EinordnungScheduler_110',
    'copy' => array(

        // Logic Hook
        array(
            'from' => '<basepath>/custom/modules/Accounts/IscEinordnungRuhendLockHook.php',
            'to'   => 'custom/modules/Accounts/IscEinordnungRuhendLockHook.php',
        ),
        array(
            'from' => '<basepath>/custom/Extension/modules/Accounts/Ext/LogicHooks/isc_einordnung_ruhend_lock.php',
            'to'   => 'custom/Extension/modules/Accounts/Ext/LogicHooks/isc_einordnung_ruhend_lock.php',
        ),

        // API
        array(
            'from' => '<basepath>/custom/clients/base/api/ISC_EinordnungConfigApi.php',
            'to'   => 'custom/clients/base/api/ISC_EinordnungConfigApi.php',
        ),

        // Drawer-Layout + -View
        array(
            'from' => '<basepath>/custom/clients/base/layouts/isc-einordnung-drawer/isc-einordnung-drawer.php',
            'to'   => 'custom/clients/base/layouts/isc-einordnung-drawer/isc-einordnung-drawer.php',
        ),
        array(
            'from' => '<basepath>/custom/clients/base/views/isc-einordnung-drawer/isc-einordnung-drawer.hbs',
            'to'   => 'custom/clients/base/views/isc-einordnung-drawer/isc-einordnung-drawer.hbs',
        ),
        array(
            'from' => '<basepath>/custom/clients/base/views/isc-einordnung-drawer/isc-einordnung-drawer.js',
            'to'   => 'custom/clients/base/views/isc-einordnung-drawer/isc-einordnung-drawer.js',
        ),

        // JS Grouping / Route
        array(
            'from' => '<basepath>/custom/Extension/application/Ext/JSGroupings/AddISC_EinordnungRoute.php',
            'to'   => 'custom/Extension/application/Ext/JSGroupings/AddISC_EinordnungRoute.php',
        ),

        // App-Sprachen
        array(
            'from' => '<basepath>/custom/Extension/application/Ext/Language/de_DE.ISC_Einordnung.php',
            'to'   => 'custom/Extension/application/Ext/Language/de_DE.ISC_Einordnung.php',
        ),
        array(
            'from' => '<basepath>/custom/Extension/application/Ext/Language/en_US.ISC_Einordnung.php',
            'to'   => 'custom/Extension/application/Ext/Language/en_US.ISC_Einordnung.php',
        ),

        // Admin-Menü + Sprache
        array(
            'from' => '<basepath>/custom/Extension/modules/Administration/Ext/Administration/isc_einordnung.php',
            'to'   => 'custom/Extension/modules/Administration/Ext/Administration/isc_einordnung.php',
        ),
        array(
            'from' => '<basepath>/custom/Extension/modules/Administration/Ext/Language/de_DE.ISC_EinordnungAdmin.php',
            'to'   => 'custom/Extension/modules/Administration/Ext/Language/de_DE.ISC_EinordnungAdmin.php',
        ),

        // Scheduler-Strings
        array(
            'from' => '<basepath>/custom/Extension/modules/Schedulers/Ext/Language/de_DE.einordnung_job.php',
            'to'   => 'custom/Extension/modules/Schedulers/Ext/Language/de_DE.einordnung_job.php',
        ),
        array(
            'from' => '<basepath>/custom/Extension/modules/Schedulers/Ext/Language/en_us.einordnung_job.php',
            'to'   => 'custom/Extension/modules/Schedulers/Ext/Language/en_us.einordnung_job.php',
        ),

        // Scheduler-Task
        array(
            'from' => '<basepath>/custom/Extension/modules/Schedulers/Ext/ScheduledTasks/set_einordnung_by_interaction_job.php',
            'to'   => 'custom/Extension/modules/Schedulers/Ext/ScheduledTasks/set_einordnung_by_interaction_job.php',
        ),

        // Zusatz-JS
        array(
            'from' => '<basepath>/custom/javascript/isc-einordnung-drawer-open.js',
            'to'   => 'custom/javascript/isc-einordnung-drawer-open.js',
        ),
        array(
            'from' => '<basepath>/custom/modules/Accounts/clients/base/fields/enum/enum.js',
            'to'   => 'custom/modules/Accounts/clients/base/fields/enum/enum.js',
        ),
    ),
);
