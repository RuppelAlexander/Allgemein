/**
 * ----------------------------------------------------------------------------
 * © ISC it & software consultants GmbH  (All rights reserved.)
 * DO NOT MODIFY THIS FILE !
 * ----------------------------------------------------------------------------
 * Author        : RuppelA
 * Create Date   : 27.10.2025
 * Change Date   : 27.10.2025
 * Main Program  : ISC_EinordnungScheduler
 * Description   : isc-einordnung-drawer.js
 * ----------------------------------------------------------------------------
 * Change Log    :
 * Date        Name    Description
 * ----------------------------------------------------------------------------
 * ----------------------------------------------------------------------------
 */
// Pfad: custom/clients/base/views/isc-einordnung-drawer/isc-einordnung-drawer.js
({
    extendsFrom: 'BaseView',

    events: {
        'click [data-action="save-settings"]': 'saveSettings',
        'click [data-action="cancel"]': 'close',
        'change [name="dry_run"]': 'toggleDryFields'
    },

    initialize: function (opts) {
        this._super('initialize', [opts]);
        this.settings = null;
        this.isLoading = true;
        this.render();
        this.loadSettings();
    },

    // ---- Helpers: DB-Format <-> <input type="datetime-local"> ----
    _dbToInput: function (val) {
        if (!val) return '';
        // erwartet "YYYY-MM-DD HH:MM:SS" -> "YYYY-MM-DDTHH:MM"
        return String(val).replace(' ', 'T').slice(0, 16);
    },
    _inputToDb: function (val) {
        if (!val) return '';
        // "YYYY-MM-DDTHH:MM" -> "YYYY-MM-DD HH:MM:SS"
        var s = String(val).replace('T', ' ');
        return s.length === 16 ? (s + ':00') : s;
    },

    loadSettings: function () {
        var self = this;
        var url  = app.api.buildURL('ISC_Einordnung/settings');

        app.api.call('read', url, null, {
            success: function (data) {
                if (self.disposed) { return; }
                var s = data || {};
                self.settings = {
                    new_m:    parseInt(s.isc_einordnung_threshold_new_contact_months     || 6, 10),
                    int_m:    parseInt(s.isc_einordnung_threshold_interessent_months     || 12, 10),
                    anb_m:    parseInt(s.isc_einordnung_threshold_anbahnungsphase_months || 12, 10),
                    akt_m:    parseInt(s.isc_einordnung_threshold_aktiv_months           || 36, 10),
                    recent_d: parseInt(s.isc_einordnung_recent_override_days             || 0, 10),
                    dry_run: (parseInt(s.isc_einordnung_dry_run || 0, 10) === 1),

                    // NEU: Rohwerte aus API
                    dry_event_when:        (s.isc_einordnung_dry_event_when || ''),
                    dry_acc_changed_at:    (s.isc_einordnung_dry_account_changed_at || ''),

                    // NEU: Werte für Inputs
                    dry_event_when_input:     '',
                    dry_acc_changed_at_input: ''
                };
                self.settings.dry_event_when_input     = self._dbToInput(self.settings.dry_event_when);
                self.settings.dry_acc_changed_at_input = self._dbToInput(self.settings.dry_acc_changed_at);

                self.isLoading = false;
                self.render();
                self.toggleDryFields(); // Sichtbarkeit nach erstem Render
            },
            error: function () {
                if (self.disposed) { return; }
                self.isLoading = false;
                self.settings = {
                    new_m: 6, int_m: 12, anb_m: 12, akt_m: 36, recent_d: 0, dry_run: false,
                    dry_event_when: '', dry_acc_changed_at: '',
                    dry_event_when_input: '', dry_acc_changed_at_input: ''
                };
                app.alert.show('isc-load-error', {
                    level: 'error',
                    messages: app.lang.get('LBL_ISC_LOAD_FAILED'),
                    autoClose: true, autoCloseDelay: 5000
                });
                self.render();
                self.toggleDryFields();
            }
        });
    },

    saveSettings: function () {
        var payload = {
            isc_einordnung_threshold_new_contact_months:      parseInt(this.$('[name=new_m]').val()   || 0, 10),
            isc_einordnung_threshold_interessent_months:      parseInt(this.$('[name=int_m]').val()   || 0, 10),
            isc_einordnung_threshold_anbahnungsphase_months:  parseInt(this.$('[name=anb_m]').val()   || 0, 10),
            isc_einordnung_threshold_aktiv_months:            parseInt(this.$('[name=akt_m]').val()   || 0, 10),
            isc_einordnung_recent_override_days:              parseInt(this.$('[name=recent_d]').val()|| 0, 10),
            isc_einordnung_dry_run:                           this.$('[name=dry_run]').is(':checked') ? 1 : 0,

            // NEU: Dry-Run-Overrides als DB-String
            isc_einordnung_dry_event_when:         this._inputToDb(this.$('[name=dry_event_when]').val()),
            isc_einordnung_dry_account_changed_at: this._inputToDb(this.$('[name=dry_acc_changed_at]').val())
        };

        var url = app.api.buildURL('ISC_Einordnung/settings');
        app.api.call('create', url, payload, {
            success: function () {
                app.alert.show('isc-save', {
                    level:'success',
                    messages: app.lang.get('LBL_ISC_SAVED'),
                    autoClose:true
                });
                app.drawer.close();
            },
            error: function () {
                app.alert.show('isc-save-err', {
                    level:'error',
                    messages: app.lang.get('LBL_ISC_SAVE_FAILED'),
                    autoClose:true, autoCloseDelay:5000
                });
            }
        });
    },

    toggleDryFields: function () {
        // zeigt/versteckt die zwei neuen Reihen
        var on = this.$('[name="dry_run"]').is(':checked');
        this.$('[data-fieldname="dry_event_when_row"]').toggle(on);
        this.$('[data-fieldname="dry_acc_changed_at_row"]').toggle(on);
    },

    close: function () { app.drawer.close(); }
});
