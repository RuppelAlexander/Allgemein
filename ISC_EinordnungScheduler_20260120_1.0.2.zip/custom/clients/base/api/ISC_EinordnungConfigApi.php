<?php
/**
 * ----------------------------------------------------------------------------
 * © ISC it & software consultants GmbH  (All rights reserved.)
 * DO NOT MODIFY THIS FILE !
 * ----------------------------------------------------------------------------
 * Author        : RuppelA
 * Create Date   : 23.10.2025
 * Change Date   : 23.10.2025
 * Main Program  : ISC_EinordnungScheduler
 * Description   : ISC_EinordnungConfigApi.php
 * ----------------------------------------------------------------------------
 * Change Log    :
 * Date        Name    Description
 * ----------------------------------------------------------------------------
 * ----------------------------------------------------------------------------
 */

// Pfad: custom/clients/base/api/ISC_EinordnungConfigApi.php

use Sugarcrm\Sugarcrm\Security\InputValidation\Request;

class ISC_EinordnungConfigApi extends SugarApi
{
    public function registerApiRest()
    {
        return [
            'getSettings' => [
                'reqType'   => 'GET',
                'path'      => ['ISC_Einordnung','settings'],
                'pathVars'  => ['', ''],
                'method'    => 'getSettings',
                'shortHelp' => 'Liest die ISC Einordnung Einstellungen',
                'minVersion'=> '11.0',
            ],
            'saveSettings' => [
                'reqType'   => 'POST',
                'path'      => ['ISC_Einordnung','settings'],
                'pathVars'  => ['', ''],
                'method'    => 'saveSettings',
                'shortHelp' => 'Speichert die ISC Einordnung Einstellungen',
                'minVersion'=> '11.0',
            ],
        ];
    }

    public function getSettings(ServiceBase $api, array $args)
    {
        $this->ensureAdmin();
        $admin = BeanFactory::newBean('Administration');
        $admin->retrieveSettings('isc_einordnung');

        // numerische Defaults
        $defNum = [
            'isc_einordnung_threshold_new_contact_months'      => 6,
            'isc_einordnung_threshold_interessent_months'      => 12,
            'isc_einordnung_threshold_anbahnungsphase_months'  => 12,
            'isc_einordnung_threshold_aktiv_months'            => 36,
            'isc_einordnung_recent_override_days'              => 0,
            'isc_einordnung_dry_run'                           => 0,
        ];
        // string Defaults (DB-Format: "YYYY-MM-DD HH:MM:SS" oder leer)
        $defStr = [
            'isc_einordnung_dry_event_when'         => '',
            'isc_einordnung_dry_account_changed_at' => '',
        ];

        $out = [];
        foreach ($defNum as $k => $v) {
            $out[$k] = isset($admin->settings[$k]) ? (int)$admin->settings[$k] : (int)$v;
        }
        foreach ($defStr as $k => $v) {
            $out[$k] = isset($admin->settings[$k]) ? (string)$admin->settings[$k] : (string)$v;
        }
        return $out;
    }

    public function saveSettings(ServiceBase $api, array $args)
    {
        $this->ensureAdmin();

        $cleanInt = function($key, $default) use ($args) {
            $val = isset($args[$key]) ? (int)$args[$key] : (int)$default;
            return max(0, $val);
        };
        $cleanStr = function($key, $default='') use ($args) {
            $val = isset($args[$key]) ? (string)$args[$key] : (string)$default;
            $val = trim($val);
            // akzeptiere leer oder "YYYY-MM-DD HH:MM[:SS]"
            if ($val !== '') {
                if (preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/', $val)) {
                    $val .= ':00';
                } elseif (!preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $val)) {
                    // ungültig -> leeren
                    $val = '';
                }
            }
            return $val;
        };

        $pairs = [
            'threshold_new_contact_months'      => $cleanInt('isc_einordnung_threshold_new_contact_months', 6),
            'threshold_interessent_months'      => $cleanInt('isc_einordnung_threshold_interessent_months', 12),
            'threshold_anbahnungsphase_months'  => $cleanInt('isc_einordnung_threshold_anbahnungsphase_months', 12),
            'threshold_aktiv_months'            => $cleanInt('isc_einordnung_threshold_aktiv_months', 36),
            'recent_override_days'              => $cleanInt('isc_einordnung_recent_override_days', 0),
            'dry_run'                           => $cleanInt('isc_einordnung_dry_run', 0) ? 1 : 0,

            // Strings
            'dry_event_when'                    => $cleanStr('isc_einordnung_dry_event_when', ''),
            'dry_account_changed_at'            => $cleanStr('isc_einordnung_dry_account_changed_at', ''),
        ];

        $admin = BeanFactory::newBean('Administration');
        foreach ($pairs as $name => $val) {
            $admin->saveSetting('isc_einordnung', $name, $val);
        }

        if (class_exists('SugarConfig')) {
            SugarConfig::getInstance()->clearCache();
        }
        return $this->getSettings($api, $args);
    }

    private function ensureAdmin(): void
    {
        if (empty($GLOBALS['current_user']) || !is_admin($GLOBALS['current_user'])) {
            throw new SugarApiExceptionNotAuthorized('Not authorized');
        }
    }
}