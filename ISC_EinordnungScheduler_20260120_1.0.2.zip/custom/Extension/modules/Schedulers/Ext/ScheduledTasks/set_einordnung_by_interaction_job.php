<?php
/**
 * ----------------------------------------------------------------------------
 * © ISC it & software consultants GmbH  (All rights reserved.)
 * DO NOT MODIFY THIS FILE !
 * ----------------------------------------------------------------------------
 * Author        : RuppelA
 * Create Date   : 10.10.2025
 * Change Date   : 16.01.2026
 * Main Program  : ISC_EinordnungScheduler
 * Description   : set_einordnung_by_interaction_job.php
 * ----------------------------------------------------------------------------
 */

// Pfad: custom/Extension/modules/Schedulers/Ext/ScheduledTasks/set_einordnung_by_interaction_job.php
// Custom Log: custom/logs/isc_einordnung_scheduler.log

$job_strings[] = 'jobSetEinordnungByScheduler';

/**
 * Scheduler-Job
 * - Setzt Accounts.einordnung_dropdown_c anhand von Zeitregeln (Baseline) und verknüpften Opportunities.sales_stage.
 * - Optional Dry-Run für Simulation (keine Saves, keine E-Mails).
 */
function jobSetEinordnungByScheduler(): bool
{
    try {
        $cfg = EinordnungSchedulerConfig::fromAdmin();
        $runner = new EinordnungSchedulerRunner($cfg);
        $runner->processAccounts();
        return true;
    } catch (\Throwable $e) {
        // Fatal in global log (nur im Fehlerfall)
        $GLOBALS['log']->fatal('ISC_EinordnungScheduler: Unhandled: ' . $e->getMessage());

        // Zusätzlich in Custom Log, falls möglich
        try {
            EinordnungSchedulerLogger::emergency('Unhandled exception: ' . $e->getMessage(), $e);
        } catch (\Throwable $ignored) {
        }

        return false;
    }
}

/**
 * Konfiguration.
 */
final class EinordnungSchedulerConfig
{
    /** Feldnamen */
    public string $FIELD_STATUS = 'einordnung_dropdown_c';
    public string $FIELD_LAST_INTERACTION = 'last_interaction_date';

    /** Dry-Run Overrides (Admin UI) */
    public ?string $DRY_EVENT_WHEN_RAW = null;
    public ?string $DRY_ACC_CHANGED_AT_RAW = null;

    /** Opportunity-Felder/Listen */
    public string $OPP_STAGE_FIELD = 'sales_stage';
    public string $OPP_STAGE_AUFTRAG = 'Auftrag';
    public string $OPP_STAGE_AUSSCHREIBUNG = 'Ausschreibung';

    /** Logging */
    public string $LOG_PREFIX = 'ISC_EinordnungScheduler';
    public bool $LOG_CHANGES = true;

    /** Dry-Run */
    public bool $DRY_RUN = false;

    /** Batchgröße */
    public int $BATCH = 300;

    /**
     * Zeit-Schwellen in MINUTEN für den Wechsel → „Ruhend“.
     * Schlüssel = aktueller Status in einordnung_dropdown_c.
     */
    public array $DORMANT_THRESHOLDS_MIN = [
        'Neukontakt'      => 43200 * 6,
        'Interessent'     => 43200 * 12,
        'Anbahnungsphase' => 43200 * 12,
        'Aktiv'           => 43200 * 36,
    ];

    /** Manuelle Stati, die nie automatisch überschrieben werden */
    public array $STATUS_MANUAL_LOCK = ['Inaktiv', 'Uninteressant'];

    /** Zielwerte */
    public string $STATUS_NC = 'Neukontakt';
    public string $STATUS_INT = 'Interessent';
    public string $STATUS_ANB = 'Anbahnungsphase';
    public string $STATUS_AKTIV = 'Aktiv';
    public string $STATUS_RUH = 'Ruhend';

    /** Ereignisse nur anwenden, wenn letzte Interaktion innerhalb dieses Fensters liegt (Minuten) */
    public int $RECENT_OVERRIDE_MIN = 0; // 0 = Events immer erlaubt

    public static function fromAdmin(): self
    {
        $s = new self();

        $admin = \BeanFactory::newBean('Administration');
        $admin->retrieveSettings('isc_einordnung');

        // Helper: int >= 0
        $get = function (string $key, int $def = 0) use ($admin): int {
            return max(0, (int)($admin->settings[$key] ?? $def));
        };

        // Monate -> Minuten, Tage -> Minuten
        $monthMin = 30 * 24 * 60;
        $dayMin = 24 * 60;

        $ncM = $get('isc_einordnung_threshold_new_contact_months', 6);
        $intM = $get('isc_einordnung_threshold_interessent_months', 12);
        $anbM = $get('isc_einordnung_threshold_anbahnungsphase_months', 12);
        $aktM = $get('isc_einordnung_threshold_aktiv_months', 36);
        $recentD = $get('isc_einordnung_recent_override_days', 0);

        $s->DORMANT_THRESHOLDS_MIN = [
            $s->STATUS_NC    => $ncM  * $monthMin,
            $s->STATUS_INT   => $intM * $monthMin,
            $s->STATUS_ANB   => $anbM * $monthMin,
            $s->STATUS_AKTIV => $aktM * $monthMin,
        ];

        $s->RECENT_OVERRIDE_MIN = $recentD * $dayMin; // 0 => Events immer erlaubt
        $s->DRY_RUN = $get('isc_einordnung_dry_run', 0) ? true : false;

        // Dry-Run Overrides (als DB-String "YYYY-MM-DD HH:MM:SS" oder leer)
        $s->DRY_EVENT_WHEN_RAW = (string)($admin->settings['isc_einordnung_dry_event_when'] ?? '') ?: null;
        $s->DRY_ACC_CHANGED_AT_RAW = (string)($admin->settings['isc_einordnung_dry_account_changed_at'] ?? '') ?: null;

        return $s;
    }
}

/**
 * Minimaler Custom-Logger (separates Logfile).
 */
final class EinordnungSchedulerLogger
{


    private bool $dryRun = false;


    public function __construct(bool $dryRun = false)
    {
        $this->dryRun = $dryRun;
    }

    public function info(string $message): void
    {
        $this->append('INFO', $message);
    }

    public function warn(string $message): void
    {
        $this->append('WARN', $message);
    }

    public function error(string $message): void
    {
        $this->append('ERROR', $message);
    }

    public static function emergency(string $message, ?\Throwable $e = null): void
    {
        try {
            $logger = new self();
            $suffix = $e ? ' | ' . get_class($e) . ': ' . $e->getMessage() : '';
            $logger->append('FATAL', $message . $suffix);
        } catch (\Throwable $ignored) {
        }
    }

    private function append(string $level, string $message): void
    {
        // Format (damit du trotzdem Timestamp + PID siehst)
        $dt  = new \DateTimeImmutable('now', new \DateTimeZone('UTC'));
        $ts  = $dt->format('Y-m-d H:i:s');
        $pid = (string) @getmypid();
        $line = sprintf('%s [%s] [%s] %s', $ts, $pid !== '' ? $pid : '-', $level, $message);

        if (empty($GLOBALS['log'])) {
            return;
        }

        // Dry-Run: alles als FATAL ins sugarcrm.log
        if ($this->dryRun) {
            $GLOBALS['log']->fatal($line);
            return;
        }

        // Live: normales Level-Mapping
        switch ($level) {
            case 'ERROR':
                $GLOBALS['log']->error($line);
                break;

            case 'WARN':
                // Sugar kann "warn" oder "warning" haben, je nach Version
                if (method_exists($GLOBALS['log'], 'warn')) {
                    $GLOBALS['log']->warn($line);
                } else {
                    $GLOBALS['log']->warning($line);
                }
                break;

            default:
                $GLOBALS['log']->info($line);
                break;
        }
    }

}

/**
 * Ausführungslogik.
 */
final class EinordnungSchedulerRunner
{
    private EinordnungSchedulerLogger $logger;

    public function __construct(private EinordnungSchedulerConfig $cfg)
    {
        $this->logger = new EinordnungSchedulerLogger($this->cfg->DRY_RUN);
        $this->logger->info("Init | dryRun=" . ($this->cfg->DRY_RUN ? '1' : '0') . " | logTarget=sugarcrm.log");

    }

    

    private function parseDb(?string $raw): ?\SugarDateTime
    {
        if (!$raw) {
            return null;
        }

        $td = \TimeDate::getInstance();
        $dt = $td->fromDb($raw);
        if ($dt instanceof \SugarDateTime) {
            return $dt;
        }

        // Fallback: reines Datum (YYYY-MM-DD)
        $dt = \SugarDateTime::createFromFormat('Y-m-d H:i:s', $raw . ' 00:00:00', new \DateTimeZone('UTC'));
        return $dt ?: null;
    }

    private function maxDt(?\SugarDateTime $a, ?\SugarDateTime $b): ?\SugarDateTime
    {
        if ($a && $b) {
            return ((int)$a->format('U') >= (int)$b->format('U')) ? $a : $b;
        }

        return $a ?: $b;
    }

    /**
     * Ermittelt die Baseline für die Ruhend-Prüfung.
     *
     * Vorgabe B&O-Bau (Step 1):
     * - Für Neukontakt/Interessent/Anbahnungsphase zählt NUR die Dauer seit Status-Setzung (Interaktionen ignorieren).
     * - Für alle anderen Status: max(Status-Setzung, letzte Interaktion).
     */
    private function determineDormantBaseline(
        string $currentStatus,
        ?\SugarDateTime $statusChangedAt,
        ?\SugarDateTime $enteredAt,
        ?\SugarDateTime $lastInteractionAt
    ): ?\SugarDateTime {
        $statusBaseline = $statusChangedAt ?? $enteredAt;

        $ignoreInteractionStatuses = [
            $this->cfg->STATUS_NC,
            $this->cfg->STATUS_INT,
            $this->cfg->STATUS_ANB,
        ];

        if (in_array($currentStatus, $ignoreInteractionStatuses, true)) {
            return $statusBaseline;
        }

        return $this->maxDt($statusBaseline, $lastInteractionAt);
    }

    private function getAccountStatusChangedAt(string $accountId, string $status): ?\SugarDateTime
    {
        $db = \DBManagerFactory::getInstance();
        $sql = sprintf(
            "SELECT date_created
             FROM accounts_audit
             WHERE parent_id=%s
               AND field_name=%s
               AND after_value_string=%s
             ORDER BY date_created DESC
             LIMIT 1",
            $db->quoted($accountId),
            $db->quoted($this->cfg->FIELD_STATUS),
            $db->quoted($status)
        );

        $dt = $db->getOne($sql);
        return $dt ? \TimeDate::getInstance()->fromDb($dt) : null;
    }

    private function logInfo(string $m): void
    {
        $this->logger->info($this->cfg->LOG_PREFIX . ': ' . $m);
    }

    private function logWarn(string $m): void
    {
        $this->logger->warn($this->cfg->LOG_PREFIX . ': ' . $m);
    }

    private function logError(string $m): void
    {
        $this->logger->error($this->cfg->LOG_PREFIX . ': ' . $m);
    }

    public function processAccounts(): void
    {
        $this->logInfo('Start');

        $offset = 0;
        $td = \TimeDate::getInstance();
        $now = $td->getNow(true); // UTC

        // Dry-Run-Overrides einmalig parsen
        $ovrEvent = $this->parseDb($this->cfg->DRY_EVENT_WHEN_RAW);
        $ovrAcc = $this->parseDb($this->cfg->DRY_ACC_CHANGED_AT_RAW);

        while (true) {
            $rows = $this->fetchAccountBatch($offset, $this->cfg->BATCH);
            if (empty($rows)) {
                break;
            }

            foreach ($rows as $row) {
                /** @var \Account|null $bean */
                $bean = \BeanFactory::retrieveBean('Accounts', $row['id'], ['disable_row_level_security' => true]);
                if (!$bean) {
                    continue;
                }

                $current = (string)($bean->{$this->cfg->FIELD_STATUS} ?? '');
                $lastRaw = (string)($bean->{$this->cfg->FIELD_LAST_INTERACTION} ?? '');

                // 0) Manuelle Sperre
                if (in_array($current, $this->cfg->STATUS_MANUAL_LOCK, true)) {
                    if ($this->cfg->DRY_RUN) {
                        $this->logInfo("DRY RUN | Account {$bean->id} | skip (manuell gesperrt) | status={$current}");
                    }
                    continue;
                }

                // Schwelle in Minuten für den aktuellen Status (Fallback: Aktiv)
                $thrMin = (int)($this->cfg->DORMANT_THRESHOLDS_MIN[$current]
                    ?? $this->cfg->DORMANT_THRESHOLDS_MIN[$this->cfg->STATUS_AKTIV]
                    ?? 0);

                // 1) Baseline bestimmen
                $lastDt = $this->parseDb($lastRaw);

                $statusChangedAt = $this->getAccountStatusChangedAt($bean->id, $current);
                if ($this->cfg->DRY_RUN && $ovrAcc instanceof \SugarDateTime) {
                    $statusChangedAt = $ovrAcc;
                }

                $enteredDt = $this->parseDb((string)($bean->date_entered ?? ''));

                $baseline = $this->determineDormantBaseline($current, $statusChangedAt, $enteredDt, $lastDt);
                $baselineStr = $baseline ? $td->asDb($baseline) : 'NULL';

                // 2) Opportunity-Event ermitteln
                $event = $this->detectEventForAccount($bean->id);
                if ($event && $this->cfg->DRY_RUN && $ovrEvent instanceof \SugarDateTime) {
                    $event['when'] = $ovrEvent;
                }

                // 2a) Event-Priorität: Event jünger als Schwelle des aktuellen Status
                $applyEvent = false;
                $ageEventMin = null;

                if ($event && ($event['when'] ?? null) instanceof \SugarDateTime && $thrMin > 0) {
                    $ageEventMin = (int)floor(((int)$now->format('U') - (int)$event['when']->format('U')) / 60);
                    $applyEvent = ($ageEventMin <= $thrMin) && (($event['target'] ?? '') !== $current);
                }

                if ($applyEvent) {
                    $this->logInfo(sprintf(
                        "%sAccount %s | %s → %s | Grund=Event | eventWhen=%s | thrMin=%s",
                        $this->cfg->DRY_RUN ? "DRY RUN | " : "",
                        $bean->id,
                        $current,
                        (string)$event['target'],
                        $td->asDb($event['when']),
                        (string)$thrMin
                    ));
                    $this->saveIfChanged($bean, (string)$event['target'], $current, $lastRaw);
                    continue;
                }

                // 3) Zeitregel „Ruhend“
                $becomeDormant = false;
                $ageMinDorm = null;

                if ($baseline instanceof \SugarDateTime && $thrMin > 0) {
                    $diffSec = max(0, (int)$now->format('U') - (int)$baseline->format('U'));
                    $ageMinDorm = (int)floor($diffSec / 60);
                    $becomeDormant = $ageMinDorm >= $thrMin;
                }

                if ($becomeDormant) {
                    if ($current !== $this->cfg->STATUS_RUH) {
                        $this->logInfo(sprintf(
                            "%sAccount %s | %s → %s | Grund=Zeitregel | baseline=%s | thrMin=%s",
                            $this->cfg->DRY_RUN ? "DRY RUN | " : "",
                            $bean->id,
                            $current,
                            $this->cfg->STATUS_RUH,
                            $baselineStr,
                            (string)$thrMin
                        ));
                        $this->saveIfChanged($bean, $this->cfg->STATUS_RUH, $current, $lastRaw);
                        continue;
                    }
                }

                // 4) Begründungs-Log bei keiner Änderung
                $reasons = [];
                $evtWhenStr = 'NULL';

                if (!$event) {
                    $reasons[] = 'kein Event';
                } else {
                    if (($event['when'] ?? null) instanceof \SugarDateTime) {
                        $evtWhenStr = $td->asDb($event['when']);
                        $ageEventMin = $ageEventMin ?? (int)floor(((int)$now->format('U') - (int)$event['when']->format('U')) / 60);

                        if (($event['target'] ?? '') === $current) {
                            $reasons[] = 'Event-Ziel==aktueller Status';
                        } elseif ($thrMin > 0 && $ageEventMin > $thrMin) {
                            $reasons[] = "Event zu alt ({$ageEventMin}/{$thrMin} min)";
                        } else {
                            $reasons[] = 'Event-Bedingungen nicht erfüllt';
                        }
                    } else {
                        $reasons[] = 'Event ohne Zeitstempel';
                    }
                }

                if (!$baseline) {
                    $reasons[] = 'Baseline leer';
                } else {
                    if ($thrMin <= 0) {
                        $reasons[] = 'keine Schwelle konfiguriert';
                    } else {
                        $ageMinDorm = $ageMinDorm ?? (int)floor(((int)$now->format('U') - (int)$baseline->format('U')) / 60);
                        if ($ageMinDorm < $thrMin) {
                            $reasons[] = "unter Schwelle ({$ageMinDorm}/{$thrMin} min)";
                        }
                    }
                }

                $this->logInfo(sprintf(
                    "Account %s | keine Änderung | status=%s | baseline=%s | eventWhen=%s | Gründe=%s",
                    $bean->id,
                    $current,
                    $baselineStr,
                    $evtWhenStr,
                    $reasons ? implode('; ', $reasons) : '—'
                ));
            }

            $offset += $this->cfg->BATCH;
        }

        $this->logInfo('Ende');
    }

    /**
     * Speichert Statusänderung und versendet ggf. E-Mail beim Wechsel nach "Ruhend".
     */
    private function saveIfChanged(\SugarBean $bean, string $new, ?string $old = null, ?string $lastRaw = null): void
    {
        $field = $this->cfg->FIELD_STATUS;
        $old ??= (string)($bean->$field ?? '');

        if ($old === $new) {
            return;
        }

        if ($this->cfg->LOG_CHANGES) {
            $this->logInfo("Account {$bean->id} | {$bean->name} : {$old} -> {$new} | letzteInteraktion={$lastRaw}");
        }

        // Dry-Run: keine Saves, keine E-Mails
        if ($this->cfg->DRY_RUN) {
            return;
        }

        $bean->isc_einordnung_scheduler_update = true;
        $bean->$field = $new;
        $bean->updateCalculatedFields = false;
        $bean->save();
        unset($bean->isc_einordnung_scheduler_update);

        if ($new === $this->cfg->STATUS_RUH && $old !== $this->cfg->STATUS_RUH) {
            $this->sendDormantNotificationEmail($bean, $old);
        }
    }


    /**
     * Ermittelt eine gültige From-Identity aus den Sugar-Mailsettings (mit Fallback).
     */
    private function resolveSystemFromIdentity(): array
    {
        $admin = \BeanFactory::newBean('Administration');
        $admin->retrieveSettings('mail');

        $fromAddress = (string)($admin->settings['mail_fromaddress'] ?? '');
        $fromName    = (string)($admin->settings['mail_fromname'] ?? '');

        // Fallbacks (verhindert SMTP 550 wegen leerem/ungültigem MAIL FROM)
        if (!filter_var($fromAddress, FILTER_VALIDATE_EMAIL)) {
            $fromAddress = 'donotreply@example.com';
        }
        if ($fromName === '') {
            $fromName = 'SugarCRM';
        }

        return [$fromAddress, $fromName];
    }

    /**
     * Erstellt System-Mailer (SMTP aus Sugar) und setzt From IMMER gültig.
     */
    private function createSystemMailer(): \SugarPHPMailer
    {
        require_once 'include/SugarPHPMailer.php';

        $mail = new \SugarPHPMailer();
        $mail->setMailerForSystem();
        $mail->isHTML(false);

        [$fromAddress, $fromName] = $this->resolveSystemFromIdentity();

        // From IMMER setzen (nicht auf Default vertrauen)
        $mail->From     = $fromAddress;
        $mail->FromName = $fromName;
        $mail->Sender   = $fromAddress;

        return $mail;
    }



    /**
     * E-Mail an assigned_user_id, sobald ein Account automatisch nach "Ruhend" wechselt.
     */
    private function sendDormantNotificationEmail(\SugarBean $accountBean, string $oldStatus): void
    {
        $assignedUserId = (string)($accountBean->assigned_user_id ?? '');
        if ($assignedUserId === '') {
            $this->logWarn("MAIL | skip | Account {$accountBean->id} | kein assigned_user_id");
            return;
        }

        /** @var \User|null $user */
        $user = \BeanFactory::retrieveBean('Users', $assignedUserId, ['disable_row_level_security' => true]);
        if (!$user) {
            $this->logWarn("MAIL | skip | Account {$accountBean->id} | assigned_user nicht gefunden ({$assignedUserId})");
            return;
        }

        $toEmail = (string)($user->email1 ?? '');
        if ($toEmail === '' && isset($user->emailAddress) && is_object($user->emailAddress)) {
            $primary = (string)$user->emailAddress->getPrimaryAddress($user);
            if ($primary !== '') {
                $toEmail = $primary;
            }
        }

        $toEmail = trim($toEmail);
        if (!filter_var($toEmail, FILTER_VALIDATE_EMAIL)) {
            $this->logWarn("MAIL | skip | Account {$accountBean->id} | ungültige Empfängeradresse: {$toEmail}");
            return;
        }

        $toName = trim((string)($user->first_name ?? '') . ' ' . (string)($user->last_name ?? ''));
        $accountName = (string)($accountBean->name ?? '');
        $recordUrl = $this->buildRecordUrl('Accounts', (string)$accountBean->id);

        $subject = "Geschäftspartner auf Ruhend gesetzt: {$accountName}";
        $body = "Hallo {$toName},\n\n"
            . "der Geschäftspartner \"{$accountName}\" wurde vom Scheduler automatisch auf \"Ruhend\" gesetzt.\n"
            . "Vorheriger Status: {$oldStatus}\n\n"
            . "Datensatz öffnen: {$recordUrl}\n\n"
            . "Viele Grüße\nSugarCRM";

        try {
            $mail = $this->createSystemMailer();

            // Sicherheit: keine Altlasten
            $mail->ClearAllRecipients();
            $mail->addAddress($toEmail, $toName ?: $toEmail);

            $mail->Subject = $subject;
            $mail->Body    = $body;

            $this->logInfo("MAIL | from={$mail->FromName} <{$mail->From}>");
            $this->logInfo("MAIL | send | Account {$accountBean->id} | to={$toEmail} | subject={$subject}");

            if (!$mail->send()) {
                $this->logError("MAIL | fail | Account {$accountBean->id} | to={$toEmail} | error=" . (string)$mail->ErrorInfo);
                return;
            }

            $this->logInfo("MAIL | sent | Account {$accountBean->id} | to={$toEmail}");
        } catch (\Throwable $e) {
            $this->logError("MAIL | exception | Account {$accountBean->id} | " . $e->getMessage());
        }
    }

    private function buildRecordUrl(string $module, string $id): string
    {
        $siteUrl = (string)($GLOBALS['sugar_config']['site_url'] ?? '');
        $siteUrl = rtrim($siteUrl, '/');

        if ($siteUrl === '' || $id === '') {
            return '';
        }

        return "{$siteUrl}/index.php#{$module}/{$id}";
    }

    /**
     * Liefert letztes relevantes Opp-Event für Account (robust über Key/Label):
     * - Auftrag       -> target = STATUS_AKTIV
     * - Ausschreibung -> target = STATUS_ANB
     * 'when' = date_modified der Opportunity
     */
    private function detectEventForAccount(string $accountId): ?array
    {
        $td = \TimeDate::getInstance();
        $opp = \BeanFactory::newBean('Opportunities');

        $sq = new \SugarQuery();
        $sq->distinct(true);
        $sq->from($opp, ['team_security' => false]);
        $sq->select(['id', $this->cfg->OPP_STAGE_FIELD, 'date_modified']);

        // Standard-Join (wie im bestehenden Paket)
        $join = $sq->joinTable('accounts_opportunities', ['alias' => 'ao', 'joinType' => 'INNER']);
        $join->on()
            ->equalsField('ao.opportunity_id', 'opportunities.id')
            ->equals('ao.account_id', $accountId)
            ->equals('ao.deleted', 0);

        $sq->where()->equals('opportunities.deleted', 0);
        $sq->limit(500);

        $rows = $sq->execute();
        if (empty($rows)) {
            return null;
        }

        $whenAuf = null;
        $whenAus = null;

        foreach ($rows as $r) {
            $stageKey = (string)($r[$this->cfg->OPP_STAGE_FIELD] ?? '');
            $dmRaw = (string)($r['date_modified'] ?? '');
            $dm = $td->fromDb($dmRaw);

            if (!$dm instanceof \SugarDateTime) {
                continue;
            }

            if ($this->matchesSalesStage($stageKey, [$this->cfg->OPP_STAGE_AUFTRAG])) {
                if (!$whenAuf || (int)$dm->format('U') > (int)$whenAuf->format('U')) {
                    $whenAuf = $dm;
                }
                continue;
            }

            if ($this->matchesSalesStage($stageKey, [$this->cfg->OPP_STAGE_AUSSCHREIBUNG])) {
                if (!$whenAus || (int)$dm->format('U') > (int)$whenAus->format('U')) {
                    $whenAus = $dm;
                }
            }
        }

        // Nimm das jüngere Event (bei Gleichstand gewinnt Auftrag)
        if ($whenAuf && $whenAus) {
            if ((int)$whenAuf->format('U') >= (int)$whenAus->format('U')) {
                return ['target' => $this->cfg->STATUS_AKTIV, 'when' => $whenAuf];
            }
            return ['target' => $this->cfg->STATUS_ANB, 'when' => $whenAus];
        }

        if ($whenAuf) {
            return ['target' => $this->cfg->STATUS_AKTIV, 'when' => $whenAuf];
        }

        if ($whenAus) {
            return ['target' => $this->cfg->STATUS_ANB, 'when' => $whenAus];
        }

        return null;
    }

    /**
     * Prüft sales_stage robust: matcht sowohl den gespeicherten Key als auch das übersetzte Label.
     */
    private function matchesSalesStage(?string $stageKey, array $targets): bool
    {
        if (empty($stageKey)) {
            return false;
        }

        $stageKeyNorm = mb_strtolower(trim($stageKey));

        // 1) Direkt gegen Key/Targets vergleichen
        foreach ($targets as $t) {
            if ($stageKeyNorm === mb_strtolower(trim((string)$t))) {
                return true;
            }
        }

        // 2) Gegen Label vergleichen
        $label = $this->translateSalesStageLabel($stageKey);
        if ($label !== '') {
            $labelNorm = mb_strtolower(trim($label));
            foreach ($targets as $t) {
                if ($labelNorm === mb_strtolower(trim((string)$t))) {
                    return true;
                }
            }
        }

        return false;
    }

    private function translateSalesStageLabel(string $stageKey): string
    {
        global $app_list_strings;

        if (!isset($app_list_strings['sales_stage_dom']) || !is_array($app_list_strings['sales_stage_dom'])) {
            return '';
        }

        return (string)($app_list_strings['sales_stage_dom'][$stageKey] ?? '');
    }

    private function fetchAccountBatch(int $offset, int $limit): array
    {
        $sq = new \SugarQuery();
        $sq->distinct(true);
        $sq->from(\BeanFactory::newBean('Accounts'), ['team_security' => false]);
        $sq->select(['id', $this->cfg->FIELD_STATUS, $this->cfg->FIELD_LAST_INTERACTION]);

        $sq->where()->equals('accounts.deleted', 0);

        $sq->orderBy('accounts.id', 'ASC');
        $sq->limit($limit);
        $sq->offset($offset);

        return $sq->execute();
    }
}
