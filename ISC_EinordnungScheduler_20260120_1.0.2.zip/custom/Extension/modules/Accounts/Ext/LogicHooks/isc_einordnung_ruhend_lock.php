<?php
/**
 * ----------------------------------------------------------------------------
 * © ISC it & software consultants GmbH  (All rights reserved.)
 * DO NOT MODIFY THIS FILE !
 * ----------------------------------------------------------------------------
 * Author        : RuppelA
 * Create Date   : 20.01.2026
 * Change Date   : 20.01.2026
 * Main Program  : ISC_EinordnungScheduler
 * Description   : isc_einordnung_ruhend_lock.php
 * ----------------------------------------------------------------------------
 * Change Log    :
 * Date        Name    Description
 * ----------------------------------------------------------------------------
 * ----------------------------------------------------------------------------
 */


// Pfad: custom/Extension/modules/Accounts/Ext/LogicHooks/isc_einordnung_ruhend_lock.php

$hook_array['before_save'][] = [
    99,
    'ISC: Block manual Ruhend changes',
    'custom/modules/Accounts/IscEinordnungRuhendLockHook.php',
    'IscEinordnungRuhendLockHook',
    'preventManualRuhendChange',
];

$hook_array['after_save'][] = [
    100,
    'ISC: Set Contacts.status_c = false when Account becomes Inaktiv',
    'custom/modules/Accounts/IscEinordnungRuhendLockHook.php',
    'IscEinordnungRuhendLockHook',
    'syncContactsOnAccountInactive',
];