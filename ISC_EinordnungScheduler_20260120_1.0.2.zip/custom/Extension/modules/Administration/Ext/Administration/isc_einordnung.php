<?php
/**
 * ----------------------------------------------------------------------------
 * © ISC it & software consultants GmbH  (All rights reserved.)
 * DO NOT MODIFY THIS FILE !
 * ----------------------------------------------------------------------------
 * Author        : RuppelA
 * Main Program  : ISC_EinordnungScheduler
 * Description   : Admin-Tile → Hash-Route
 * ----------------------------------------------------------------------------
 */
// Pfad: custom/Extension/modules/Administration/Ext/Administration/isc_einordnung.php

$admin_option_defs = array();
$admin_option_defs['Administration']['isc_einordnung_button'] = array(
    'Administration',
    'LBL_ISC_EINORDNUNG_TITLE',
    'LBL_ISC_EINORDNUNG_DESCRIPTION',
    'javascript:parent.SUGAR.App.router.navigate("#Administration/isc_einordnung", {trigger: true});'
);
$admin_group_header[] = array(
    'LBL_ISC_EINORDNUNG_SECTION_HEADER',
    '',
    false,
    $admin_option_defs,
    'LBL_ISC_EINORDNUNG_SECTION_DESCRIPTION'
);
