<?php
/**
 * ----------------------------------------------------------------------------
 * © ISC it & software consultants GmbH  (All rights reserved.)
 * DO NOT MODIFY THIS FILE !
 * ----------------------------------------------------------------------------
 * Author        : RuppelA
 * Create Date   : 22.10.2025
 * Change Date   : 22.10.2025
 * Main Program  : ISC_EinordnungScheduler
 * Description   : de_DE.ISC_EinordnungAdmin.php
 * ----------------------------------------------------------------------------
 * Change Log    :
 * Date        Name    Description
 * ----------------------------------------------------------------------------
 * ----------------------------------------------------------------------------
 */

// Pfad: custom/Extension/modules/Administration/Ext/Language/de_DE.ISC_EinordnungAdmin.php
$mod_strings['LBL_ISC_EINORDNUNG_TITLE'] = 'ISC Einordnung – Einstellungen';
$mod_strings['LBL_ISC_EINORDNUNG_DESCRIPTION'] = 'Konfiguration für Einordnung-Scheduler';
$mod_strings['LBL_ISC_EINORDNUNG_SECTION_HEADER'] = 'ISC Einordnung';
$mod_strings['LBL_ISC_EINORDNUNG_SECTION_DESCRIPTION'] = 'Öffnet die Einordnung-Konfiguration im Drawer';