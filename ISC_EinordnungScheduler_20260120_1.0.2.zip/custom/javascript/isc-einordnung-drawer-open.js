/**
 * ----------------------------------------------------------------------------
 * © ISC it & software consultants GmbH  (All rights reserved.)
 * DO NOT MODIFY THIS FILE !
 * ----------------------------------------------------------------------------
 * Author        : RuppelA
 * Main Program  : ISC_EinordnungScheduler
 * Description   : Sidecar-Route + Drawer-Open
 * ----------------------------------------------------------------------------
 */
// Pfad: custom/javascript/isc-einordnung-drawer-open.js

(function(app) {
    app.events.on('router:init', function() {
        app.router.route('Administration/isc_einordnung', 'isc_einordnung', function() {
            app.drawer.open({
                layout: 'isc-einordnung-drawer',
                context: {
                    module: 'Home',
                    create: true,
                    fromRouter: true,
                    labelText: app.lang.get('LBL_ISC_EINORDNUNG_TITLE')
                }
            });
        });
    });
})(SUGAR.App);





