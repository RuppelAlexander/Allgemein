<?php
/**
 * ----------------------------------------------------------------------------
 * © ISC it & software consultants GmbH  (All rights reserved.)
 * DO NOT MODIFY THIS FILE !
 * ----------------------------------------------------------------------------
 * Author        : RuppelA
 * Create Date   : 20.01.2026
 * Change Date   : 20.01.2026
 * Main Program  : ISC_EinordnungScheduler
 * Description   : IscEinordnungRuhendLockHook.php
 * ----------------------------------------------------------------------------
 * Change Log    :
 * Date        Name    Description
 * ----------------------------------------------------------------------------
 * ----------------------------------------------------------------------------
 */


// Pfad: custom/modules/Accounts/IscEinordnungRuhendLockHook.php

class IscEinordnungRuhendLockHook
{
    private const FIELD_STATUS = 'einordnung_dropdown_c';
    private const STATUS_RUHEND = 'Ruhend';
    private const DEFAULT_STATUS = 'Neukontakt';

    /**
     * Blockt jede manuelle Änderung, die "Ruhend" betrifft:
     * - von Ruhend weg
     * - zu Ruhend hin
     * Scheduler darf über Flag $bean->isc_einordnung_scheduler_update trotzdem ändern.
     */
    public function preventManualRuhendChange(\SugarBean $bean, string $event, array $arguments): void
    {
        // Scheduler darf (automatisch) setzen/ändern
        if (!empty($bean->isc_einordnung_scheduler_update)) {
            return;
        }

        $field = self::FIELD_STATUS;

        $new = (string)($bean->$field ?? '');
        $old = (string)($bean->fetched_row[$field] ?? '');

        // keine Änderung => nix tun
        if ($new === $old) {
            return;
        }

        $touchesRuhend = ($new === self::STATUS_RUHEND) || ($old === self::STATUS_RUHEND);
        if (!$touchesRuhend) {
            return;
        }

        // Bei Neuanlage könnte $old leer sein -> dann auf Default zurück
        $revertTo = $old !== '' ? $old : self::DEFAULT_STATUS;

        // Revert
        $bean->$field = $revertTo;

        // Optional: Feedback im UI (Sidecar zeigt i.d.R. die Meldung oben)
        if (class_exists('SugarApplication')) {
            \SugarApplication::appendErrorMessage('Der Status "Ruhend" ist nicht manuell änderbar und wird nur automatisch gesetzt.');
        }

        // Optional: Log
        if (!empty($GLOBALS['log'])) {
            $GLOBALS['log']->info(sprintf(
                'ISC_EinordnungScheduler: LOCK | blocked manual Ruhend change | account=%s | old=%s | attempted=%s | revertedTo=%s',
                (string)$bean->id,
                $old,
                $new,
                $revertTo
            ));
        }
    }

    public function syncContactsOnAccountInactive(\SugarBean $bean, string $event, array $arguments): void
    {
        // Nur Accounts
        if (($bean->module_dir ?? '') !== 'Accounts') {
            return;
        }

        $field = self::FIELD_STATUS;

        $newStatus = (string)($bean->$field ?? '');

        // Nur wenn wirklich Wechsel auf "Inaktiv"
        if ($newStatus !== 'Inaktiv') {
            return;
        }

        // Kontakte laden (Standard Relationship)
        $contacts = [];
        if ($bean->load_relationship('contacts') && is_object($bean->contacts)) {
            $contacts = $bean->contacts->getBeans();
        }

        if (empty($contacts)) {
            return;
        }

        foreach ($contacts as $contact) {
            if (!$contact instanceof \Contact) {
                continue;
            }


            $current = (string)($contact->status_c ?? '');

            // Nur ändern wenn nötig
            if ($current === '0') {
                continue;
            }

            $contact->isc_account_inaktiv_sync = true;
            $contact->status_c = '0';
            $contact->updateCalculatedFields = false;
            $contact->save();
            unset($contact->isc_account_inaktiv_sync);
        }
    }




}
