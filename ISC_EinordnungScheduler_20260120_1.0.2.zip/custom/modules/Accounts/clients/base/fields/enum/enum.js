/**
 * ----------------------------------------------------------------------------
 * © ISC it & software consultants GmbH  (All rights reserved.)
 * DO NOT MODIFY THIS FILE !
 * ----------------------------------------------------------------------------
 * Author        : RuppelA
 * Create Date   : 20.01.2026
 * Change Date   : 20.01.2026
 * Main Program  : ISC_EinordnungScheduler
 * Description   : enum.js
 * ----------------------------------------------------------------------------
 * Change Log    :
 * Date        Name    Description
 * ----------------------------------------------------------------------------
 * ----------------------------------------------------------------------------
 */

/*
* ISC - Einordnung Dropdown: "Ruhend" darf manuell nicht gesetzt/entfernt werden.
* - Wenn Status != Ruhend: Option "Ruhend" ist disabled (ausgegraut) und nicht wählbar
* - Wenn Status == Ruhend: komplettes Feld disabled (User kann nicht wegwechseln)
*/
({
    extendsFrom: 'EnumField',

    // Konstante definieren für bessere Wartbarkeit
    CONST_RUHEND: 'Ruhend',

    bindDataChange: function () {
        this._super('bindDataChange');
        // Überwacht Änderungen, um das ganze Feld zu sperren, wenn der Wert bereits "Ruhend" ist
        if (this.name === 'einordnung_dropdown_c' && this.model) {
            this.model.on('change:' + this.name, this._checkFieldLockState, this);
        }
    },

   
    getSelect2Options: function (optionsKeys) {
        var options = this._super('getSelect2Options', [optionsKeys]);
        var self = this;

        // Originalen Formatter sichern, falls vorhanden
        var originalFormatResult = options.formatResult;

        // Custom Formatter für die Dropdown-Liste
        options.formatResult = function (state) {
            var label = originalFormatResult ? originalFormatResult(state) : state.text;

            // Wenn die Option "Ruhend" ist -> Grau färben und Cursor ändern
            if (state.id === self.CONST_RUHEND) {
                return '<span style="color: #a9a9a9; cursor: not-allowed;">' + label + '</span>';
            }
            return label;
        };

        return options;
    },

    _render: function () {
        this._super('_render');
        this._checkFieldLockState();
        this._bindSelectionBlocker();
    },

    /**
     * Verhindert logisch das Anklicken der Option "Ruhend"
     */
    _bindSelectionBlocker: function() {
        var $field = this.$(this.fieldTag);
        var self = this;

        if (!$field || !$field.length) {
            return;
        }

        $field.off('.iscRuhend');

        
        // Event: Bevor eine Auswahl getroffen wird
        $field.on('select2-selecting.iscRuhend select2:selecting.iscRuhend', function(e) {

            // v3 liefert e.val, v4 liefert e.params.args.data.id (je nach Setup)
            var val = e.val
                || (e.params && e.params.args && e.params.args.data && e.params.args.data.id);

            if (val === self.CONST_RUHEND) {
                e.preventDefault();
            }
        });
    },

    /**
     * Logik: Wenn Datensatz bereits "Ruhend" ist -> Feld komplett Readonly
     */
    _checkFieldLockState: function () {
        // Sicherheitschecks
        if (this.name !== 'einordnung_dropdown_c' || this.disposed) {
            return;
        }

        // Nur im Edit/Create Modus relevant
        var action = this.action || (this.view && this.view.action) || '';
        if (action !== 'edit' && action !== 'create') {
            return;
        }

        var current = this.model.get(this.name);
        var $el = this.$(this.fieldTag);

        if (!$el || !$el.length || !$el.data('select2')) {
            return;
        }

        if (current === this.CONST_RUHEND) {

            $el.select2('disable');
        } else {

            $el.select2('enable');
        }
    }
})